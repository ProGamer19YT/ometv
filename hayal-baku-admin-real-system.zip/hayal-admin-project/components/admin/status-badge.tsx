import { Badge } from '@/components/ui/badge'
import { cn } from '@/lib/utils'

const tones = {
  success: 'border-emerald-500/30 bg-emerald-500/10 text-emerald-300',
  warning: 'border-amber-500/30 bg-amber-500/10 text-amber-200',
  danger: 'border-rose-500/30 bg-rose-500/10 text-rose-300',
  info: 'border-sky-500/30 bg-sky-500/10 text-sky-200',
  muted: 'border-border bg-secondary text-secondary-foreground',
}

export function StatusBadge({
  label,
  tone = 'muted',
}: {
  label: string
  tone?: keyof typeof tones
}) {
  return <Badge className={cn('rounded-full px-3 py-1 font-medium', tones[tone])}>{label}</Badge>
}
