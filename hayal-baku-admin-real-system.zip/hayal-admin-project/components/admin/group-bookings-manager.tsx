'use client'

import { useMemo, useState } from 'react'
import { Mail, Search, Trash2 } from 'lucide-react'

import { ConfirmActionDialog } from '@/components/admin/confirm-action-dialog'
import { EmptyState } from '@/components/admin/empty-state'
import { PageHeader } from '@/components/admin/page-header'
import { StatusBadge } from '@/components/admin/status-badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Drawer, DrawerContent, DrawerHeader, DrawerTitle } from '@/components/ui/drawer'
import { Input } from '@/components/ui/input'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { Textarea } from '@/components/ui/textarea'
import { hasPermission } from '@/lib/admin/auth'
import { useAdminData } from '@/lib/admin/data-context'
import type { GroupBooking } from '@/lib/admin/types'
import { formatDateTime, groupBookingStatusTone } from '@/lib/admin/utils'

const statuses = ['Yeni sorğu', 'Baxılır', 'Təklif göndərildi', 'Təsdiqləndi', 'Bağlandı', 'Ləğv edildi'] as const

export function GroupBookingsManager() {
  const { state, currentUser, updateGroupBookingStatus, deleteGroupBooking, upsertGroupBooking } = useAdminData()
  const canManage = hasPermission(currentUser?.role, 'group.manage')

  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState('all')
  const [selected, setSelected] = useState<GroupBooking | null>(null)

  const rows = useMemo(() => {
    return state.groupBookings.filter((item) => {
      const matchesSearch = [item.personOrCompany, item.phone, item.eventType, item.email].join(' ').toLowerCase().includes(search.toLowerCase())
      const matchesStatus = statusFilter === 'all' || item.status === statusFilter
      return matchesSearch && matchesStatus
    })
  }, [search, state.groupBookings, statusFilter])

  if (!canManage) {
    return <EmptyState icon={Search} title="Bu modul üçün icazəniz yoxdur" description="Qrup rezervasiyaları modulu yalnız menecer və super admin üçün aktivdir." />
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Özəl tədbirlər / qrup rezervasiyaları" description="Şəxs və şirkət sorğuları, təklif məbləği, admin qeydi və status idarəetməsi bu modulda toplanır." />

      <Card className="border-border/60 bg-card/70">
        <CardHeader>
          <CardTitle>Sorğular</CardTitle>
          <CardDescription>Filtrləmə, axtarış və detallı drawer görünüşü.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-3 md:grid-cols-3">
            <div className="relative md:col-span-2">
              <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
              <Input className="pl-9" placeholder="Ad, şirkət, e-poçt və ya tədbir növü üzrə axtarış" value={search} onChange={(e) => setSearch(e.target.value)} />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger><SelectValue placeholder="Statusa görə filtr" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Bütün statuslar</SelectItem>
                {statuses.map((status) => <SelectItem key={status} value={status}>{status}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>

          {rows.length === 0 ? (
            <EmptyState icon={Search} title="Sorğu tapılmadı" description="Filtrləri dəyişin və ya yeni sorğu əlavə edin." />
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Şəxs / şirkət adı</TableHead>
                    <TableHead>Tədbir növü</TableHead>
                    <TableHead>Qonaq sayı</TableHead>
                    <TableHead>Tarix</TableHead>
                    <TableHead>Büdcə</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Əməliyyat</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {rows.map((item) => (
                    <TableRow key={item.id}>
                      <TableCell>
                        <div>
                          <p className="font-medium">{item.personOrCompany}</p>
                          <p className="text-xs text-muted-foreground">{item.phone}</p>
                        </div>
                      </TableCell>
                      <TableCell>{item.eventType}</TableCell>
                      <TableCell>{item.guestCount}</TableCell>
                      <TableCell>{item.date} • {item.time}</TableCell>
                      <TableCell>{item.budget}</TableCell>
                      <TableCell><StatusBadge label={item.status} tone={groupBookingStatusTone(item.status)} /></TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button variant="ghost" size="sm" onClick={() => setSelected(item)}>Detallar</Button>
                          <ConfirmActionDialog
                            trigger={<Button variant="ghost" size="icon-sm"><Trash2 className="size-4" /></Button>}
                            title="Sorğunu sil"
                            description="Bu sorğu siyahıdan silinəcək."
                            onConfirm={() => deleteGroupBooking(item.id)}
                          />
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <Drawer open={Boolean(selected)} onOpenChange={(open) => !open && setSelected(null)}>
        <DrawerContent className="max-h-[90vh]">
          {selected ? (
            <div className="mx-auto w-full max-w-4xl overflow-y-auto px-4 pb-6">
              <DrawerHeader className="px-0">
                <DrawerTitle>Tədbir detalları</DrawerTitle>
              </DrawerHeader>
              <div className="grid gap-6 lg:grid-cols-[0.85fr_1.15fr]">
                <Card className="border-border/60 bg-card/70">
                  <CardContent className="space-y-4 px-5 py-5">
                    <div><p className="text-sm text-muted-foreground">Şəxs / şirkət adı</p><p className="font-medium">{selected.personOrCompany}</p></div>
                    <div><p className="text-sm text-muted-foreground">Telefon</p><p className="font-medium">{selected.phone}</p></div>
                    <div><p className="text-sm text-muted-foreground">E-poçt</p><p className="font-medium">{selected.email}</p></div>
                    <div><p className="text-sm text-muted-foreground">Tədbir növü</p><p className="font-medium">{selected.eventType}</p></div>
                    <div><p className="text-sm text-muted-foreground">Qonaq sayı</p><p className="font-medium">{selected.guestCount}</p></div>
                    <div><p className="text-sm text-muted-foreground">Tarix / Saat</p><p className="font-medium">{selected.date} • {selected.time}</p></div>
                    <div className="flex flex-wrap gap-2">
                      <Button asChild variant="outline"><a href={`mailto:${selected.email}`}><Mail className="size-4" /> E-poçt aç</a></Button>
                    </div>
                  </CardContent>
                </Card>

                <div className="space-y-6">
                  <Card className="border-border/60 bg-card/70">
                    <CardHeader><CardTitle>Status və təklif</CardTitle></CardHeader>
                    <CardContent className="space-y-4">
                      <Select value={selected.status} onValueChange={(value) => { updateGroupBookingStatus(selected.id, value as GroupBooking['status']); setSelected({ ...selected, status: value as GroupBooking['status'] }) }}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {statuses.map((status) => <SelectItem key={status} value={status}>{status}</SelectItem>)}
                        </SelectContent>
                      </Select>
                      <div className="space-y-2">
                        <p className="text-sm font-medium">Təklif məbləği</p>
                        <Input value={selected.proposalAmount ?? ''} onChange={(e) => setSelected({ ...selected, proposalAmount: e.target.value })} />
                        <Button onClick={() => upsertGroupBooking(selected)}>Təklifi yadda saxla</Button>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="border-border/60 bg-card/70">
                    <CardHeader><CardTitle>Qeyd və admin qeydi</CardTitle></CardHeader>
                    <CardContent className="space-y-4">
                      <div><p className="text-sm text-muted-foreground">Əlavə qeyd</p><p className="text-sm">{selected.note || 'Qeyd yoxdur'}</p></div>
                      <div className="space-y-2">
                        <p className="text-sm font-medium">Admin daxili qeyd</p>
                        <Textarea value={selected.adminNote} onChange={(e) => setSelected({ ...selected, adminNote: e.target.value })} />
                        <Button onClick={() => upsertGroupBooking(selected)}>Admin qeydini saxla</Button>
                      </div>
                      <p className="text-xs text-muted-foreground">Yaradılma tarixi: {formatDateTime(selected.createdAt)}</p>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </div>
          ) : null}
        </DrawerContent>
      </Drawer>
    </div>
  )
}
