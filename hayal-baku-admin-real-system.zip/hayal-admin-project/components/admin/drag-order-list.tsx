'use client'

import * as React from 'react'
import { GripVertical, MoveVertical } from 'lucide-react'

import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { cn } from '@/lib/utils'

export function DragOrderList<T extends { id: string }>({
  items,
  getLabel,
  onChange,
}: {
  items: T[]
  getLabel: (item: T) => string
  onChange: (items: T[]) => void
}) {
  const [dragId, setDragId] = React.useState<string | null>(null)

  const moveItem = (sourceId: string, targetId: string) => {
    const sourceIndex = items.findIndex((item) => item.id === sourceId)
    const targetIndex = items.findIndex((item) => item.id === targetId)
    if (sourceIndex === -1 || targetIndex === -1 || sourceIndex === targetIndex) return
    const clone = [...items]
    const [removed] = clone.splice(sourceIndex, 1)
    clone.splice(targetIndex, 0, removed)
    onChange(clone)
  }

  return (
    <div className="space-y-3">
      {items.map((item) => (
        <Card
          key={item.id}
          draggable
          onDragStart={() => setDragId(item.id)}
          onDragOver={(event) => event.preventDefault()}
          onDrop={() => {
            if (dragId) moveItem(dragId, item.id)
            setDragId(null)
          }}
          className={cn('border-border/60 bg-card/60 transition', dragId === item.id && 'border-primary/50')}
        >
          <CardContent className="flex items-center justify-between gap-4 px-4 py-3">
            <div className="flex items-center gap-3">
              <div className="rounded-xl border border-border/70 bg-background/60 p-2 text-muted-foreground">
                <GripVertical className="size-4" />
              </div>
              <div>
                <p className="font-medium">{getLabel(item)}</p>
                <p className="text-xs text-muted-foreground">Sürüşdür və burax ilə sıralamanı dəyiş</p>
              </div>
            </div>
            <Button variant="ghost" size="icon-sm" className="rounded-full">
              <MoveVertical className="size-4" />
            </Button>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
