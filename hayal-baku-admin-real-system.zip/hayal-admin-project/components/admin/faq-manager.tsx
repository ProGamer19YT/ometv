'use client'

import { useState } from 'react'
import { Plus, Trash2 } from 'lucide-react'

import { ConfirmActionDialog } from '@/components/admin/confirm-action-dialog'
import { DragOrderList } from '@/components/admin/drag-order-list'
import { PageHeader } from '@/components/admin/page-header'
import { StatusBadge } from '@/components/admin/status-badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Textarea } from '@/components/ui/textarea'
import { useAdminData } from '@/lib/admin/data-context'
import type { FAQItem } from '@/lib/admin/types'
import { createId } from '@/lib/admin/utils'

export function FAQManager() {
  const { state, upsertFaqItem, deleteFaqItem, reorderFaqItems } = useAdminData()
  const [dialogOpen, setDialogOpen] = useState(false)
  const [form, setForm] = useState<FAQItem>({ id: '', question: '', answer: '', order: state.faqItems.length + 1, isActive: true })

  const openDialog = (item?: FAQItem) => {
    setForm(item ?? { id: '', question: '', answer: '', order: state.faqItems.length + 1, isActive: true })
    setDialogOpen(true)
  }

  return (
    <div className="space-y-6">
      <PageHeader title="FAQ" description="Dinamik sual-cavab bloku, drag and drop sıralama və aktiv / passiv idarəetməsi." actions={<Button onClick={() => openDialog()}><Plus className="size-4" /> FAQ əlavə et</Button>} />

      <Card className="border-border/60 bg-card/70">
        <CardHeader>
          <CardTitle>Drag and drop sıralama</CardTitle>
          <CardDescription>Public saytda göstəriləcək ardıcıllığı dəyişin.</CardDescription>
        </CardHeader>
        <CardContent>
          <DragOrderList items={[...state.faqItems].sort((a, b) => a.order - b.order)} getLabel={(item) => item.question} onChange={reorderFaqItems} />
        </CardContent>
      </Card>

      <div className="grid gap-4 lg:grid-cols-2">
        {state.faqItems.map((item) => (
          <Card key={item.id} className="border-border/60 bg-card/70">
            <CardContent className="space-y-4 px-5 py-5">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <p className="font-medium">{item.question}</p>
                  <p className="text-xs text-muted-foreground">Sıralama: {item.order}</p>
                </div>
                <StatusBadge label={item.isActive ? 'Aktiv' : 'Passiv'} tone={item.isActive ? 'success' : 'muted'} />
              </div>
              <p className="text-sm text-muted-foreground">{item.answer}</p>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm" onClick={() => openDialog(item)}>Redaktə et</Button>
                <ConfirmActionDialog trigger={<Button variant="ghost" size="icon-sm"><Trash2 className="size-4" /></Button>} title="FAQ elementini sil" description="Seçilən sual-cavab elementi silinəcək." onConfirm={() => deleteFaqItem(item.id)} />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{form.id ? 'FAQ elementini redaktə et' : 'FAQ əlavə et'}</DialogTitle>
            <DialogDescription>Sual, cavab, sıralama və aktiv statusu buradan dəyişin.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4">
            <div className="space-y-2"><Label>Sual</Label><Input value={form.question} onChange={(e) => setForm({ ...form, question: e.target.value })} /></div>
            <div className="space-y-2"><Label>Cavab</Label><Textarea value={form.answer} onChange={(e) => setForm({ ...form, answer: e.target.value })} /></div>
            <div className="space-y-2"><Label>Sıralama</Label><Input type="number" value={form.order} onChange={(e) => setForm({ ...form, order: Number(e.target.value) })} /></div>
            <div className="flex items-center justify-between rounded-2xl border border-border/60 bg-background/40 px-4 py-3"><Label>Aktiv / passiv</Label><Switch checked={form.isActive} onCheckedChange={(checked) => setForm({ ...form, isActive: checked })} /></div>
            <Button onClick={() => { upsertFaqItem({ ...form, id: form.id || createId('faq') }); setDialogOpen(false) }}>Yadda saxla</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
