'use client'

import { useState } from 'react'
import { Plus, Trash2 } from 'lucide-react'

import { ConfirmActionDialog } from '@/components/admin/confirm-action-dialog'
import { PageHeader } from '@/components/admin/page-header'
import { StatusBadge } from '@/components/admin/status-badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Textarea } from '@/components/ui/textarea'
import { useAdminData } from '@/lib/admin/data-context'
import type { Testimonial } from '@/lib/admin/types'
import { createId } from '@/lib/admin/utils'

export function TestimonialsManager() {
  const { state, upsertTestimonial, deleteTestimonial } = useAdminData()
  const [dialogOpen, setDialogOpen] = useState(false)
  const [form, setForm] = useState<Testimonial>({ id: '', customerName: '', text: '', rating: 5, image: '/placeholder-user.jpg', isVisible: true, order: state.testimonials.length + 1 })

  const openDialog = (item?: Testimonial) => {
    setForm(item ?? { id: '', customerName: '', text: '', rating: 5, image: '/placeholder-user.jpg', isVisible: true, order: state.testimonials.length + 1 })
    setDialogOpen(true)
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Rəylər" description="CRUD, görün / gizlət statusu və sıralama ilə rəy idarəetməsi." actions={<Button onClick={() => openDialog()}><Plus className="size-4" /> Yeni rəy əlavə et</Button>} />

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {state.testimonials.map((item) => (
          <Card key={item.id} className="border-border/60 bg-card/70">
            <CardContent className="space-y-4 px-5 py-5">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <p className="font-medium">{item.customerName}</p>
                  <p className="text-xs text-muted-foreground">Reytinq: {item.rating}/5</p>
                </div>
                <StatusBadge label={item.isVisible ? 'Görünür' : 'Gizli'} tone={item.isVisible ? 'success' : 'muted'} />
              </div>
              <p className="text-sm text-muted-foreground">{item.text}</p>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm" onClick={() => openDialog(item)}>Redaktə et</Button>
                <ConfirmActionDialog
                  trigger={<Button variant="ghost" size="icon-sm"><Trash2 className="size-4" /></Button>}
                  title="Rəyi sil"
                  description="Seçilən rəy idarəetmə panelindən silinəcək."
                  onConfirm={() => deleteTestimonial(item.id)}
                />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{form.id ? 'Rəyi redaktə et' : 'Yeni rəy əlavə et'}</DialogTitle>
            <DialogDescription>Saytda göstər / gizlət və sıralama idarəetməsi ilə.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4">
            <div className="space-y-2"><Label>Müştəri adı</Label><Input value={form.customerName} onChange={(e) => setForm({ ...form, customerName: e.target.value })} /></div>
            <div className="space-y-2"><Label>Rəy mətni</Label><Textarea value={form.text} onChange={(e) => setForm({ ...form, text: e.target.value })} /></div>
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2"><Label>Reytinq</Label><Input type="number" min={1} max={5} value={form.rating} onChange={(e) => setForm({ ...form, rating: Number(e.target.value) })} /></div>
              <div className="space-y-2"><Label>Sıralama</Label><Input type="number" value={form.order} onChange={(e) => setForm({ ...form, order: Number(e.target.value) })} /></div>
            </div>
            <div className="space-y-2"><Label>Şəkil (opsional)</Label><Input value={form.image} onChange={(e) => setForm({ ...form, image: e.target.value })} /></div>
            <div className="flex items-center justify-between rounded-2xl border border-border/60 bg-background/40 px-4 py-3"><Label>Saytda görünsün / gizlənsin</Label><Switch checked={form.isVisible} onCheckedChange={(checked) => setForm({ ...form, isVisible: checked })} /></div>
            <Button onClick={() => { upsertTestimonial({ ...form, id: form.id || createId('tes') }); setDialogOpen(false) }}>Yadda saxla</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
