'use client'

import { useState } from 'react'
import { MapPin, Save } from 'lucide-react'

import { PageHeader } from '@/components/admin/page-header'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { useAdminData } from '@/lib/admin/data-context'

export function ContactManager() {
  const { state, saveContactInfo } = useAdminData()
  const [form, setForm] = useState(state.contactInfo)
  const [isSaving, setIsSaving] = useState(false)

  const onSave = async () => {
    setIsSaving(true)
    await new Promise((resolve) => setTimeout(resolve, 600))
    saveContactInfo(form)
    setIsSaving(false)
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Əlaqə məlumatları" description="Ünvan, nömrələr, iş saatları, sosial linklər və sayt ön baxış bloku buradan idarə olunur." actions={<Button onClick={onSave} disabled={isSaving}><Save className="size-4" /> {isSaving ? 'Saxlanılır...' : 'Yadda saxla'}</Button>} />
      <div className="grid gap-6 xl:grid-cols-[1.05fr_0.95fr]">
        <Card className="border-border/60 bg-card/70">
          <CardHeader><CardTitle>Əlaqə formu</CardTitle><CardDescription>Saytın əlaqə bölməsi üçün bütün sahələri yenilə.</CardDescription></CardHeader>
          <CardContent className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2 md:col-span-2"><Label>Ünvan</Label><Input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} /></div>
            <div className="space-y-2"><Label>Əlaqə nömrəsi</Label><Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></div>
            <div className="space-y-2"><Label>Alternativ nömrə</Label><Input value={form.alternatePhone} onChange={(e) => setForm({ ...form, alternatePhone: e.target.value })} /></div>
            <div className="space-y-2"><Label>E-poçt</Label><Input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
            <div className="space-y-2"><Label>İş saatları</Label><Input value={form.workingHours} onChange={(e) => setForm({ ...form, workingHours: e.target.value })} /></div>
            <div className="space-y-2 md:col-span-2"><Label>Instagram linki</Label><Input value={form.instagram} onChange={(e) => setForm({ ...form, instagram: e.target.value })} /></div>
            <div className="space-y-2 md:col-span-2"><Label>Google Maps embed linki</Label><Input value={form.mapsEmbedUrl} onChange={(e) => setForm({ ...form, mapsEmbedUrl: e.target.value })} /></div>
            <div className="space-y-2 md:col-span-2"><Label>Park məlumatı</Label><Textarea value={form.parkingInfo} onChange={(e) => setForm({ ...form, parkingInfo: e.target.value })} /></div>
            <div className="space-y-2 md:col-span-2"><Label>Qısa əlaqə təsviri</Label><Textarea value={form.shortDescription} onChange={(e) => setForm({ ...form, shortDescription: e.target.value })} /></div>
          </CardContent>
        </Card>

        <Card className="border-border/60 bg-card/70">
          <CardHeader><CardTitle>Saytda göstər preview bloku</CardTitle><CardDescription>Public vebsaytda əlaqə kartının ön baxışı.</CardDescription></CardHeader>
          <CardContent>
            <div className="rounded-[28px] border border-primary/20 bg-[linear-gradient(180deg,rgba(214,165,82,0.10),rgba(20,18,16,0.9))] p-6">
              <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/10 px-3 py-1 text-xs text-primary">
                <MapPin className="size-4" /> Saytda göstər
              </div>
              <div className="space-y-3">
                <h3 className="text-xl font-semibold">Əlaqə məlumatları</h3>
                <p className="text-sm text-muted-foreground">{form.shortDescription}</p>
                <div className="rounded-2xl border border-border/60 bg-background/50 p-4 text-sm">
                  <p><span className="text-muted-foreground">Ünvan:</span> {form.address}</p>
                  <p><span className="text-muted-foreground">Telefon:</span> {form.phone}</p>
                  <p><span className="text-muted-foreground">Alternativ:</span> {form.alternatePhone}</p>
                  <p><span className="text-muted-foreground">E-poçt:</span> {form.email}</p>
                  <p><span className="text-muted-foreground">İş saatları:</span> {form.workingHours}</p>
                  <p><span className="text-muted-foreground">Park:</span> {form.parkingInfo}</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
