'use client'

import { useMemo, useState } from 'react'
import { Eye, Filter, Plus, Search, Trash2 } from 'lucide-react'

import { ConfirmActionDialog } from '@/components/admin/confirm-action-dialog'
import { EmptyState } from '@/components/admin/empty-state'
import { PageHeader } from '@/components/admin/page-header'
import { StatusBadge } from '@/components/admin/status-badge'
import { Button } from '@/components/ui/button'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { Textarea } from '@/components/ui/textarea'
import { hasPermission } from '@/lib/admin/auth'
import { useAdminData } from '@/lib/admin/data-context'
import type { MenuCategory, MenuItem } from '@/lib/admin/types'
import { createId } from '@/lib/admin/utils'

const PAGE_SIZE = 6

export function MenuManager() {
  const {
    state,
    currentUser,
    upsertMenuCategory,
    deleteMenuCategory,
    upsertMenuItem,
    deleteMenuItem,
    bulkDeleteMenuItems,
    bulkSetMenuItemsActive,
  } = useAdminData()

  const canManage = hasPermission(currentUser?.role, 'menu.manage')

  const [search, setSearch] = useState('')
  const [categoryFilter, setCategoryFilter] = useState('all')
  const [statusFilter, setStatusFilter] = useState('all')
  const [page, setPage] = useState(1)
  const [selectedIds, setSelectedIds] = useState<string[]>([])
  const [itemDialogOpen, setItemDialogOpen] = useState(false)
  const [categoryDialogOpen, setCategoryDialogOpen] = useState(false)
  const [previewItem, setPreviewItem] = useState<MenuItem | null>(null)
  const [categoryForm, setCategoryForm] = useState<MenuCategory>({ id: '', name: '', isActive: true, order: state.menuCategories.length + 1 })
  const [itemForm, setItemForm] = useState<MenuItem>({
    id: '',
    name: '',
    description: '',
    price: 0,
    image: '/placeholder.jpg',
    categoryId: state.menuCategories[0]?.id ?? '',
    isSignature: false,
    availability: 'Mövcuddur',
    order: state.menuItems.length + 1,
    isActive: true,
  })

  const filteredItems = useMemo(() => {
    return state.menuItems.filter((item) => {
      const category = state.menuCategories.find((entry) => entry.id === item.categoryId)
      const matchesSearch = [item.name, item.description, category?.name ?? ''].join(' ').toLowerCase().includes(search.toLowerCase())
      const matchesCategory = categoryFilter === 'all' || item.categoryId === categoryFilter
      const matchesStatus =
        statusFilter === 'all' ||
        (statusFilter === 'active' ? item.isActive : !item.isActive)
      return matchesSearch && matchesCategory && matchesStatus
    })
  }, [categoryFilter, search, state.menuCategories, state.menuItems, statusFilter])

  const pageCount = Math.max(1, Math.ceil(filteredItems.length / PAGE_SIZE))
  const pagedItems = filteredItems.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE)

  const openCategoryDialog = (item?: MenuCategory) => {
    setCategoryForm(item ?? { id: '', name: '', isActive: true, order: state.menuCategories.length + 1 })
    setCategoryDialogOpen(true)
  }

  const openItemDialog = (item?: MenuItem) => {
    setItemForm(
      item ?? {
        id: '',
        name: '',
        description: '',
        price: 0,
        image: '/placeholder.jpg',
        categoryId: state.menuCategories[0]?.id ?? '',
        isSignature: false,
        availability: 'Mövcuddur',
        order: state.menuItems.length + 1,
        isActive: true,
      },
    )
    setItemDialogOpen(true)
  }

  if (!canManage) {
    return (
      <EmptyState icon={Filter} title="Bu modul üçün icazəniz yoxdur" description="Menyu idarəetməsi yalnız uyğun rol olan istifadəçilər üçün aktivdir." />
    )
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="Menyu idarəetməsi"
        description="Kateqoriyalar, məhsullar, axtarış, filtrlər, toplu əməliyyatlar və ön baxış bu bölmədə toplanır."
        actions={
          <>
            <Button variant="outline" onClick={() => openCategoryDialog()}>
              <Plus className="size-4" />
              Yeni kateqoriya əlavə et
            </Button>
            <Button onClick={() => openItemDialog()}>
              <Plus className="size-4" />
              Yeni məhsul əlavə et
            </Button>
          </>
        }
      />

      <div className="grid gap-6 xl:grid-cols-[0.75fr_1.25fr]">
        <Card className="border-border/60 bg-card/70">
          <CardHeader>
            <CardTitle>Kateqoriyalar</CardTitle>
            <CardDescription>Aktiv / passiv status və sıralama.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {state.menuCategories.map((category) => (
              <div key={category.id} className="flex items-center justify-between rounded-2xl border border-border/60 bg-background/40 p-4">
                <div>
                  <p className="font-medium">{category.name}</p>
                  <p className="text-xs text-muted-foreground">Sıralama: {category.order}</p>
                </div>
                <div className="flex items-center gap-2">
                  <StatusBadge label={category.isActive ? 'Aktiv' : 'Passiv'} tone={category.isActive ? 'success' : 'muted'} />
                  <Button variant="ghost" size="sm" onClick={() => openCategoryDialog(category)}>
                    Redaktə et
                  </Button>
                  <ConfirmActionDialog
                    trigger={<Button variant="ghost" size="icon-sm"><Trash2 className="size-4" /></Button>}
                    title="Kateqoriyanı sil"
                    description="Kateqoriya ilə birlikdə bu kateqoriyaya bağlı məhsullar da silinəcək."
                    onConfirm={() => deleteMenuCategory(category.id)}
                  />
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card className="border-border/60 bg-card/70">
          <CardHeader>
            <CardTitle>Məhsullar</CardTitle>
            <CardDescription>Axtarış, filtr, toplu silmə və ön baxış.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-3 md:grid-cols-4">
              <div className="relative md:col-span-2">
                <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
                <Input className="pl-9" placeholder="Məhsul axtarışı" value={search} onChange={(e) => setSearch(e.target.value)} />
              </div>
              <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Kateqoriya üzrə filtr" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Bütün kateqoriyalar</SelectItem>
                  {state.menuCategories.map((category) => (
                    <SelectItem key={category.id} value={category.id}>{category.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Status üzrə filtr" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Bütün statuslar</SelectItem>
                  <SelectItem value="active">Aktiv</SelectItem>
                  <SelectItem value="passive">Passiv</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {selectedIds.length > 0 ? (
              <div className="flex flex-wrap items-center gap-2 rounded-2xl border border-primary/20 bg-primary/10 p-3">
                <span className="text-sm text-primary">Seçilən məhsul sayı: {selectedIds.length}</span>
                <Button size="sm" variant="outline" onClick={() => bulkSetMenuItemsActive(selectedIds, true)}>Toplu aktivləşdir</Button>
                <Button size="sm" variant="outline" onClick={() => bulkSetMenuItemsActive(selectedIds, false)}>Toplu deaktiv et</Button>
                <Button size="sm" variant="destructive" onClick={() => bulkDeleteMenuItems(selectedIds)}>Toplu sil</Button>
              </div>
            ) : null}

            {filteredItems.length === 0 ? (
              <EmptyState icon={Search} title="Nəticə tapılmadı" description="Axtarış və filtr parametrlərini dəyişərək yenidən cəhd edin." />
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-10"></TableHead>
                      <TableHead>Məhsul adı</TableHead>
                      <TableHead>Kateqoriya</TableHead>
                      <TableHead>Qiymət</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>İmza</TableHead>
                      <TableHead className="text-right">Əməliyyat</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {pagedItems.map((item) => {
                      const category = state.menuCategories.find((entry) => entry.id === item.categoryId)
                      const selected = selectedIds.includes(item.id)
                      return (
                        <TableRow key={item.id}>
                          <TableCell>
                            <input
                              type="checkbox"
                              checked={selected}
                              onChange={() => setSelectedIds((prev) => prev.includes(item.id) ? prev.filter((id) => id !== item.id) : [...prev, item.id])}
                            />
                          </TableCell>
                          <TableCell>
                            <div>
                              <p className="font-medium">{item.name}</p>
                              <p className="max-w-xs truncate text-xs text-muted-foreground">{item.description}</p>
                            </div>
                          </TableCell>
                          <TableCell>{category?.name ?? '—'}</TableCell>
                          <TableCell>{item.price} AZN</TableCell>
                          <TableCell>
                            <StatusBadge label={item.isActive ? 'Aktiv' : 'Passiv'} tone={item.isActive ? 'success' : 'muted'} />
                          </TableCell>
                          <TableCell>
                            <StatusBadge label={item.isSignature ? 'İmza məhsul' : 'Standart'} tone={item.isSignature ? 'info' : 'muted'} />
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <Button variant="ghost" size="icon-sm" onClick={() => setPreviewItem(item)}>
                                <Eye className="size-4" />
                              </Button>
                              <Button variant="ghost" size="sm" onClick={() => openItemDialog(item)}>Redaktə et</Button>
                              <ConfirmActionDialog
                                trigger={<Button variant="ghost" size="icon-sm"><Trash2 className="size-4" /></Button>}
                                title="Məhsulu sil"
                                description="Bu əməliyyat məhsulu idarəetmə panelindən siləcək."
                                onConfirm={() => deleteMenuItem(item.id)}
                              />
                            </div>
                          </TableCell>
                        </TableRow>
                      )
                    })}
                  </TableBody>
                </Table>
                <div className="mt-4 flex items-center justify-between">
                  <p className="text-sm text-muted-foreground">Səhifə {page} / {pageCount}</p>
                  <div className="flex gap-2">
                    <Button variant="outline" disabled={page === 1} onClick={() => setPage((prev) => prev - 1)}>Əvvəlki</Button>
                    <Button variant="outline" disabled={page === pageCount} onClick={() => setPage((prev) => prev + 1)}>Növbəti</Button>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Dialog open={categoryDialogOpen} onOpenChange={setCategoryDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{categoryForm.id ? 'Kateqoriyanı redaktə et' : 'Yeni kateqoriya əlavə et'}</DialogTitle>
            <DialogDescription>Kateqoriya adı, status və sıralama sahələri.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Kateqoriya adı</Label>
              <Input value={categoryForm.name} onChange={(e) => setCategoryForm({ ...categoryForm, name: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>Sıralama</Label>
              <Input type="number" value={categoryForm.order} onChange={(e) => setCategoryForm({ ...categoryForm, order: Number(e.target.value) })} />
            </div>
            <div className="flex items-center justify-between rounded-2xl border border-border/60 bg-background/40 px-4 py-3">
              <Label>Aktiv / passiv et</Label>
              <Switch checked={categoryForm.isActive} onCheckedChange={(checked) => setCategoryForm({ ...categoryForm, isActive: checked })} />
            </div>
            <Button className="w-full" onClick={() => { upsertMenuCategory({ ...categoryForm, id: categoryForm.id || createId('cat') }); setCategoryDialogOpen(false) }}>Yadda saxla</Button>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={itemDialogOpen} onOpenChange={setItemDialogOpen}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle>{itemForm.id ? 'Məhsulu redaktə et' : 'Yeni məhsul əlavə et'}</DialogTitle>
            <DialogDescription>Məhsul məlumatları sonradan backend və fayl upload qatına asan bağlana biləcək strukturla saxlanılır.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2 md:col-span-2">
              <Label>Məhsul adı</Label>
              <Input value={itemForm.name} onChange={(e) => setItemForm({ ...itemForm, name: e.target.value })} />
            </div>
            <div className="space-y-2 md:col-span-2">
              <Label>Təsvir</Label>
              <Textarea value={itemForm.description} onChange={(e) => setItemForm({ ...itemForm, description: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>Qiymət (AZN)</Label>
              <Input type="number" value={itemForm.price} onChange={(e) => setItemForm({ ...itemForm, price: Number(e.target.value) })} />
            </div>
            <div className="space-y-2">
              <Label>Şəkil</Label>
              <Input value={itemForm.image} onChange={(e) => setItemForm({ ...itemForm, image: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>Kateqoriya</Label>
              <Select value={itemForm.categoryId} onValueChange={(value) => setItemForm({ ...itemForm, categoryId: value })}>
                <SelectTrigger><SelectValue placeholder="Kateqoriya seçin" /></SelectTrigger>
                <SelectContent>
                  {state.menuCategories.map((category) => (
                    <SelectItem key={category.id} value={category.id}>{category.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Status</Label>
              <Select value={itemForm.availability} onValueChange={(value: MenuItem['availability']) => setItemForm({ ...itemForm, availability: value })}>
                <SelectTrigger><SelectValue placeholder="Mövcudluq" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Mövcuddur">Mövcuddur</SelectItem>
                  <SelectItem value="Mövcud deyil">Mövcud deyil</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Sıralama</Label>
              <Input type="number" value={itemForm.order} onChange={(e) => setItemForm({ ...itemForm, order: Number(e.target.value) })} />
            </div>
            <div className="flex items-center justify-between rounded-2xl border border-border/60 bg-background/40 px-4 py-3">
              <Label>İmza məhsul statusu</Label>
              <Switch checked={itemForm.isSignature} onCheckedChange={(checked) => setItemForm({ ...itemForm, isSignature: checked })} />
            </div>
            <div className="flex items-center justify-between rounded-2xl border border-border/60 bg-background/40 px-4 py-3 md:col-span-2">
              <Label>Aktiv / passiv statusu</Label>
              <Switch checked={itemForm.isActive} onCheckedChange={(checked) => setItemForm({ ...itemForm, isActive: checked })} />
            </div>
            <Button className="md:col-span-2" onClick={() => { upsertMenuItem({ ...itemForm, id: itemForm.id || createId('item') }); setItemDialogOpen(false) }}>Yadda saxla</Button>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={Boolean(previewItem)} onOpenChange={(open) => !open && setPreviewItem(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Ön baxış</DialogTitle>
            <DialogDescription>Məhsul kartının public saytda necə görünəcəyini göstərən ön baxış.</DialogDescription>
          </DialogHeader>
          {previewItem ? (
            <Card className="border-border/60 bg-card/70">
              <CardContent className="space-y-4 px-5 py-5">
                <img src={previewItem.image} alt={previewItem.name} className="h-48 w-full rounded-2xl object-cover" />
                <div className="space-y-2">
                  <div className="flex items-center justify-between gap-4">
                    <h3 className="text-lg font-semibold">{previewItem.name}</h3>
                    <p className="text-sm font-medium">{previewItem.price} AZN</p>
                  </div>
                  <p className="text-sm text-muted-foreground">{previewItem.description}</p>
                  <div className="flex flex-wrap gap-2">
                    <StatusBadge label={previewItem.availability} tone={previewItem.availability === 'Mövcuddur' ? 'success' : 'warning'} />
                    <StatusBadge label={previewItem.isSignature ? 'İmza məhsul' : 'Standart'} tone={previewItem.isSignature ? 'info' : 'muted'} />
                  </div>
                </div>
              </CardContent>
            </Card>
          ) : null}
        </DialogContent>
      </Dialog>
    </div>
  )
}
