'use client'

import Link from 'next/link'
import {
  BellRing,
  BookOpenText,
  CalendarCheck2,
  ClipboardList,
  LayoutList,
  MessageSquareQuote,
  PencilLine,
  Settings2,
  Sparkles,
  UtensilsCrossed,
} from 'lucide-react'
import { Area, AreaChart, CartesianGrid, XAxis } from 'recharts'

import { PageHeader } from '@/components/admin/page-header'
import { StatCard } from '@/components/admin/stat-card'
import { StatusBadge } from '@/components/admin/status-badge'
import {
  Card,
  CardAction,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from '@/components/ui/chart'
import { Button } from '@/components/ui/button'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { useAdminData } from '@/lib/admin/data-context'
import { formatDate, formatDateTime, reservationStatusTone } from '@/lib/admin/utils'

export function DashboardView() {
  const { state, currentUser } = useAdminData()

  const today = new Date().toISOString().slice(0, 10)
  const todayReservations = state.reservations.filter((item) => item.date === today)
  const pendingReservations = state.reservations.filter((item) => item.status === 'Gözləyir')
  const approvedReservations = state.reservations.filter((item) => item.status === 'Təsdiqləndi')
  const visibleTestimonials = state.testimonials.filter((item) => item.isVisible)
  const activeCategories = state.menuCategories.filter((item) => item.isActive)

  const chartData = [
    { day: 'B.e', reservations: 8, groups: 1 },
    { day: 'Ç.a', reservations: 11, groups: 2 },
    { day: 'Ç', reservations: 9, groups: 2 },
    { day: 'C.a', reservations: 14, groups: 3 },
    { day: 'C', reservations: 12, groups: 2 },
    { day: 'Ş', reservations: 18, groups: 4 },
    { day: 'B', reservations: 16, groups: 3 },
  ]

  return (
    <div className="space-y-6">
      <PageHeader
        title="Dashboard"
        description="Günün rezervasiya vəziyyəti, son dəyişikliklər, audit log və idarəetmə keçidləri bir ekranda toplanır."
        actions={
          <>
            <Button asChild variant="outline">
              <Link href="/admin/menu">Menyuya keç</Link>
            </Button>
            <Button asChild>
              <Link href="/admin/reservations">Rezervasiyalara bax</Link>
            </Button>
          </>
        }
      />

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <StatCard title="Bugünkü rezervasiya sayı" value={String(todayReservations.length)} helper="Cari gün üçün daxil olan sorğular" icon={CalendarCheck2} />
        <StatCard title="Gözləyən rezervasiyalar" value={String(pendingReservations.length)} helper="Təsdiq gözləyən masa sifarişləri" icon={ClipboardList} />
        <StatCard title="Təsdiqlənmiş rezervasiyalar" value={String(approvedReservations.length)} helper="Dəqiqləşdirilmiş sifarişlər" icon={BookOpenText} />
        <StatCard title="Yeni qrup sifarişləri" value={String(state.groupBookings.filter((item) => item.status === 'Yeni sorğu').length)} helper="Komanda və tədbir sorğuları" icon={Sparkles} />
        <StatCard title="Aktiv menyu kateqoriyaları" value={String(activeCategories.length)} helper="Görünən menyu bölmələri" icon={UtensilsCrossed} />
        <StatCard title="Saytda görünən rəylər" value={String(visibleTestimonials.length)} helper="Hal-hazırda aktiv rəylər" icon={MessageSquareQuote} />
        <StatCard title="Son yenilənmə tarixi" value={state.auditLogs[0] ? formatDate(state.auditLogs[0].timestamp) : '—'} helper="Audit log üzrə son dəyişiklik" icon={PencilLine} />
        <StatCard title="Son daxil olan admin" value={currentUser?.name ?? 'Sistem admin'} helper={currentUser?.lastLogin ? formatDateTime(currentUser.lastLogin) : 'Sessiya aktivdir'} icon={BellRing} />
      </div>

      <div className="grid gap-6 xl:grid-cols-[1.4fr_0.8fr]">
        <Card className="border-border/60 bg-card/70">
          <CardHeader>
            <CardTitle>Rezervasiya trendi</CardTitle>
            <CardDescription>Rezervasiya və qrup sorğularının həftəlik əməliyyat görünüşü.</CardDescription>
            <CardAction>
              <StatusBadge label="Aktiv sistem" tone="info" />
            </CardAction>
          </CardHeader>
          <CardContent>
            <ChartContainer
              className="h-[280px] w-full"
              config={{
                reservations: { label: 'Rezervasiyalar', color: 'var(--chart-1)' },
                groups: { label: 'Qrup sorğuları', color: 'var(--chart-2)' },
              }}
            >
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="fillReservations" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="var(--color-reservations)" stopOpacity={0.35} />
                    <stop offset="95%" stopColor="var(--color-reservations)" stopOpacity={0.05} />
                  </linearGradient>
                  <linearGradient id="fillGroups" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="var(--color-groups)" stopOpacity={0.35} />
                    <stop offset="95%" stopColor="var(--color-groups)" stopOpacity={0.05} />
                  </linearGradient>
                </defs>
                <CartesianGrid vertical={false} />
                <XAxis dataKey="day" tickLine={false} axisLine={false} tickMargin={12} />
                <ChartTooltip content={<ChartTooltipContent />} />
                <Area type="monotone" dataKey="reservations" stroke="var(--color-reservations)" fill="url(#fillReservations)" strokeWidth={2} />
                <Area type="monotone" dataKey="groups" stroke="var(--color-groups)" fill="url(#fillGroups)" strokeWidth={2} />
              </AreaChart>
            </ChartContainer>
          </CardContent>
        </Card>

        <Card className="border-border/60 bg-card/70">
          <CardHeader>
            <CardTitle>Sürətli keçidlər</CardTitle>
            <CardDescription>Tez istifadə olunan modullara bir kliklə keç.</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-3">
            {[
              { href: '/admin/menu', label: 'Menyuya keç' },
              { href: '/admin/reservations', label: 'Rezervasiyalara bax' },
              { href: '/admin/gallery', label: 'Qalereyanı yenilə' },
              { href: '/admin/contact', label: 'Əlaqə məlumatlarını dəyiş' },
              { href: '/admin/seo', label: 'SEO ayarları' },
            ].map((item) => (
              <Button key={item.href} asChild variant="outline" className="justify-start">
                <Link href={item.href}>{item.label}</Link>
              </Button>
            ))}
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 xl:grid-cols-[1.2fr_0.8fr]">
        <Card className="border-border/60 bg-card/70">
          <CardHeader>
            <CardTitle>Son rezervasiyalar</CardTitle>
            <CardDescription>Masa sifarişlərinin cari vəziyyəti.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Ad</TableHead>
                    <TableHead>Tarix</TableHead>
                    <TableHead>Saat</TableHead>
                    <TableHead>Qonaq</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {state.reservations.slice(0, 5).map((item) => (
                    <TableRow key={item.id}>
                      <TableCell>
                        <div>
                          <p className="font-medium">{item.name}</p>
                          <p className="text-xs text-muted-foreground">{item.phone}</p>
                        </div>
                      </TableCell>
                      <TableCell>{item.date}</TableCell>
                      <TableCell>{item.time}</TableCell>
                      <TableCell>{item.guestCount}</TableCell>
                      <TableCell>
                        <StatusBadge label={item.status} tone={reservationStatusTone(item.status)} />
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border/60 bg-card/70">
          <CardHeader>
            <CardTitle>Son məzmun dəyişiklikləri</CardTitle>
            <CardDescription>Audit log üçün əsas struktur.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {state.auditLogs.slice(0, 6).map((log) => (
              <div key={log.id} className="flex gap-3 rounded-2xl border border-border/60 bg-background/40 p-4">
                <div className="mt-1 rounded-full border border-primary/20 bg-primary/10 p-2 text-primary">
                  <LayoutList className="size-4" />
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-medium">{log.action}</p>
                  <p className="text-xs text-muted-foreground">{log.module} • {log.user}</p>
                  <p className="text-sm text-muted-foreground">{log.detail}</p>
                  <p className="text-xs text-muted-foreground">{formatDateTime(log.timestamp)}</p>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
