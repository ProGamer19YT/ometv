'use client'

import { useState } from 'react'
import { Plus, Save } from 'lucide-react'
import { toast } from 'sonner'

import { PageHeader } from '@/components/admin/page-header'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Textarea } from '@/components/ui/textarea'
import { useAdminData } from '@/lib/admin/data-context'

export function SiteContentManager() {
  const { state, saveSiteContent } = useAdminData()
  const [content, setContent] = useState(state.siteContent)
  const [isSaving, setIsSaving] = useState(false)

  const save = async () => {
    setIsSaving(true)
    await new Promise((resolve) => setTimeout(resolve, 700))
    saveSiteContent(content)
    setIsSaving(false)
  }

  const updateAboutCard = (index: number, key: 'title' | 'text', value: string) => {
    const nextCards = [...content.about.cards]
    nextCards[index] = { ...nextCards[index], [key]: value }
    setContent({ ...content, about: { ...content.about, cards: nextCards } })
  }

  const updateExperienceCard = (index: number, key: 'title' | 'description' | 'order', value: string | number) => {
    const nextCards = [...content.signatureExperience.cards]
    nextCards[index] = { ...nextCards[index], [key]: value }
    setContent({ ...content, signatureExperience: { ...content.signatureExperience, cards: nextCards } })
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="Sayt məzmunu"
        description="Public saytın əsas bölmələrini buradan redaktə edin. Dəqiq məlumat məlum olmadıqda placeholder mətnləri sonradan dəyişmək üçün saxlayın."
        actions={
          <Button onClick={save} disabled={isSaving}>
            <Save className="size-4" />
            {isSaving ? 'Yadda saxlanılır...' : 'Dəyişiklikləri saxla'}
          </Button>
        }
      />

      <Tabs defaultValue="hero" className="space-y-6">
        <TabsList className="grid w-full gap-2 md:grid-cols-5">
          <TabsTrigger value="hero">Hero bölməsi</TabsTrigger>
          <TabsTrigger value="about">Haqqımızda</TabsTrigger>
          <TabsTrigger value="experience">İmza təcrübəsi</TabsTrigger>
          <TabsTrigger value="cta">Son CTA</TabsTrigger>
          <TabsTrigger value="footer">Footer</TabsTrigger>
        </TabsList>

        <TabsContent value="hero">
          <Card className="border-border/60 bg-card/70">
            <CardHeader>
              <CardTitle>Hero bölməsi</CardTitle>
              <CardDescription>Başlıq, CTA və vizual parametrləri.</CardDescription>
            </CardHeader>
            <CardContent className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2 md:col-span-2">
                <Label>Başlıq</Label>
                <Input value={content.hero.title} onChange={(e) => setContent({ ...content, hero: { ...content.hero, title: e.target.value } })} />
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label>Alt başlıq</Label>
                <Textarea value={content.hero.subtitle} onChange={(e) => setContent({ ...content, hero: { ...content.hero, subtitle: e.target.value } })} />
              </div>
              <div className="space-y-2">
                <Label>Əsas CTA mətni</Label>
                <Input value={content.hero.primaryCta} onChange={(e) => setContent({ ...content, hero: { ...content.hero, primaryCta: e.target.value } })} />
              </div>
              <div className="space-y-2">
                <Label>İkinci CTA mətni</Label>
                <Input value={content.hero.secondaryCta} onChange={(e) => setContent({ ...content, hero: { ...content.hero, secondaryCta: e.target.value } })} />
              </div>
              <div className="space-y-2">
                <Label>Hero tag-ləri</Label>
                <Input
                  value={content.hero.tags.join(', ')}
                  onChange={(e) => setContent({ ...content, hero: { ...content.hero, tags: e.target.value.split(',').map((item) => item.trim()).filter(Boolean) } })}
                />
              </div>
              <div className="space-y-2">
                <Label>Hero vizualı / şəkil</Label>
                <Input value={content.hero.visual} onChange={(e) => setContent({ ...content, hero: { ...content.hero, visual: e.target.value } })} />
              </div>
              <div className="flex items-center justify-between rounded-2xl border border-border/60 bg-background/40 px-4 py-3 md:col-span-2">
                <div>
                  <p className="font-medium">Aktiv / passiv statusu</p>
                  <p className="text-sm text-muted-foreground">Saytda bu blokun göstərilməsini idarə edir.</p>
                </div>
                <Switch checked={content.hero.isActive} onCheckedChange={(checked) => setContent({ ...content, hero: { ...content.hero, isActive: checked } })} />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="about">
          <Card className="border-border/60 bg-card/70">
            <CardHeader>
              <CardTitle>Haqqımızda</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Bölmə başlığı</Label>
                <Input value={content.about.title} onChange={(e) => setContent({ ...content, about: { ...content.about, title: e.target.value } })} />
              </div>
              <div className="space-y-2">
                <Label>Mətn</Label>
                <Textarea value={content.about.text} onChange={(e) => setContent({ ...content, about: { ...content.about, text: e.target.value } })} />
              </div>
              <div className="grid gap-4 md:grid-cols-3">
                {content.about.cards.map((card, index) => (
                  <Card key={card.id} className="border-border/60 bg-background/40">
                    <CardContent className="space-y-3 px-4 py-4">
                      <Input value={card.title} onChange={(e) => updateAboutCard(index, 'title', e.target.value)} placeholder="Kart başlığı" />
                      <Textarea value={card.text} onChange={(e) => updateAboutCard(index, 'text', e.target.value)} placeholder="Kart mətni" />
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="experience">
          <Card className="border-border/60 bg-card/70">
            <CardHeader>
              <CardTitle>İmza təcrübəsi</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label>Bölmə başlığı</Label>
                  <Input value={content.signatureExperience.title} onChange={(e) => setContent({ ...content, signatureExperience: { ...content.signatureExperience, title: e.target.value } })} />
                </div>
                <div className="space-y-2">
                  <Label>Alt mətn</Label>
                  <Input value={content.signatureExperience.subtitle} onChange={(e) => setContent({ ...content, signatureExperience: { ...content.signatureExperience, subtitle: e.target.value } })} />
                </div>
              </div>
              <div className="grid gap-4 lg:grid-cols-3">
                {content.signatureExperience.cards.map((card, index) => (
                  <Card key={card.id} className="border-border/60 bg-background/40">
                    <CardContent className="space-y-3 px-4 py-4">
                      <Input value={card.title} onChange={(e) => updateExperienceCard(index, 'title', e.target.value)} placeholder="Başlıq" />
                      <Textarea value={card.description} onChange={(e) => updateExperienceCard(index, 'description', e.target.value)} placeholder="Təsvir" />
                      <Input type="number" value={card.order} onChange={(e) => updateExperienceCard(index, 'order', Number(e.target.value))} placeholder="Sıralama" />
                    </CardContent>
                  </Card>
                ))}
              </div>
              <Button
                variant="outline"
                onClick={() => {
                  setContent({
                    ...content,
                    signatureExperience: {
                      ...content.signatureExperience,
                      cards: [
                        ...content.signatureExperience.cards,
                        {
                          id: `exp_${Date.now()}`,
                          title: 'Yeni təcrübə kartı',
                          description: 'Redaktə edilə bilən təsvir sahəsi.',
                          order: content.signatureExperience.cards.length + 1,
                        },
                      ],
                    },
                  })
                  toast.success('Yeni təcrübə kartı əlavə olundu')
                }}
              >
                <Plus className="size-4" />
                Kart əlavə et
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="cta">
          <Card className="border-border/60 bg-card/70">
            <CardHeader>
              <CardTitle>Son CTA</CardTitle>
            </CardHeader>
            <CardContent className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2 md:col-span-2">
                <Label>Başlıq</Label>
                <Input value={content.finalCta.title} onChange={(e) => setContent({ ...content, finalCta: { ...content.finalCta, title: e.target.value } })} />
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label>Təsvir</Label>
                <Textarea value={content.finalCta.description} onChange={(e) => setContent({ ...content, finalCta: { ...content.finalCta, description: e.target.value } })} />
              </div>
              <div className="space-y-2">
                <Label>Əsas düymə mətni</Label>
                <Input value={content.finalCta.primaryButton} onChange={(e) => setContent({ ...content, finalCta: { ...content.finalCta, primaryButton: e.target.value } })} />
              </div>
              <div className="space-y-2">
                <Label>İkinci düymə mətni</Label>
                <Input value={content.finalCta.secondaryButton} onChange={(e) => setContent({ ...content, finalCta: { ...content.finalCta, secondaryButton: e.target.value } })} />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="footer">
          <Card className="border-border/60 bg-card/70">
            <CardHeader>
              <CardTitle>Footer mətnləri</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Qısa təsvir</Label>
                <Textarea value={content.footer.description} onChange={(e) => setContent({ ...content, footer: { ...content.footer, description: e.target.value } })} />
              </div>
              <div className="grid gap-4 md:grid-cols-3">
                {content.footer.links.map((link, index) => (
                  <Card key={link.id} className="border-border/60 bg-background/40">
                    <CardContent className="space-y-3 px-4 py-4">
                      <Input
                        value={link.label}
                        onChange={(e) => {
                          const nextLinks = [...content.footer.links]
                          nextLinks[index] = { ...nextLinks[index], label: e.target.value }
                          setContent({ ...content, footer: { ...content.footer, links: nextLinks } })
                        }}
                        placeholder="Link mətni"
                      />
                      <Input
                        value={link.href}
                        onChange={(e) => {
                          const nextLinks = [...content.footer.links]
                          nextLinks[index] = { ...nextLinks[index], href: e.target.value }
                          setContent({ ...content, footer: { ...content.footer, links: nextLinks } })
                        }}
                        placeholder="URL"
                      />
                    </CardContent>
                  </Card>
                ))}
              </div>
              <div className="space-y-2">
                <Label>Copyright mətni</Label>
                <Input value={content.footer.copyright} onChange={(e) => setContent({ ...content, footer: { ...content.footer, copyright: e.target.value } })} />
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
