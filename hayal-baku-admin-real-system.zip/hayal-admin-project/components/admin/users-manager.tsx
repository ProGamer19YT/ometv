'use client'

import { useState } from 'react'
import { KeyRound, Plus, Shield } from 'lucide-react'
import { toast } from 'sonner'

import { EmptyState } from '@/components/admin/empty-state'
import { PageHeader } from '@/components/admin/page-header'
import { StatusBadge } from '@/components/admin/status-badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { hasPermission } from '@/lib/admin/auth'
import { roleLabels } from '@/lib/admin/constants'
import { useAdminData } from '@/lib/admin/data-context'
import type { User } from '@/lib/admin/types'
import { createId, formatDateTime } from '@/lib/admin/utils'

export function UsersManager() {
  const { state, currentUser, upsertUser, toggleUserStatus } = useAdminData()
  const canManage = currentUser?.role === 'super_admin'
  const [dialogOpen, setDialogOpen] = useState(false)
  const [form, setForm] = useState<User>({ id: '', name: '', email: '', role: 'content_editor', isActive: true, lastLogin: new Date().toISOString() })

  const openDialog = (user?: User) => {
    setForm(user ?? { id: '', name: '', email: '', role: 'content_editor', isActive: true, lastLogin: new Date().toISOString() })
    setDialogOpen(true)
  }

  if (!canManage) {
    return <EmptyState icon={Shield} title="Bu modul yalnız super admin üçündür" description="Kontent redaktoru və menecer bu bölməni yalnız super admin hesabı ilə idarə edə bilər." />
  }

  return (
    <div className="space-y-6">
      <PageHeader title="İstifadəçilər" description="Rol əsaslı görünüş, aktiv / passiv statusu, şifrə sıfırlama axını və son giriş vaxtı idarəetməsi." actions={<Button onClick={() => openDialog()}><Plus className="size-4" /> Yeni istifadəçi əlavə et</Button>} />
      <Card className="border-border/60 bg-card/70">
        <CardHeader><CardTitle>İstifadəçi siyahısı</CardTitle><CardDescription>Super admin hər şeyi idarə edə bilər, menecer məhdud, kontent redaktoru daha məhdud hüquqlarla işləyir.</CardDescription></CardHeader>
        <CardContent className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Ad</TableHead>
                <TableHead>E-poçt</TableHead>
                <TableHead>Rol</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Son giriş vaxtı</TableHead>
                <TableHead className="text-right">Əməliyyat</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {state.users.map((user) => (
                <TableRow key={user.id}>
                  <TableCell className="font-medium">{user.name}</TableCell>
                  <TableCell>{user.email}</TableCell>
                  <TableCell>{roleLabels[user.role]}</TableCell>
                  <TableCell><StatusBadge label={user.isActive ? 'Aktiv' : 'Passiv'} tone={user.isActive ? 'success' : 'muted'} /></TableCell>
                  <TableCell>{formatDateTime(user.lastLogin)}</TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button variant="outline" size="sm" onClick={() => openDialog(user)}>Redaktə et</Button>
                      <Button variant="outline" size="sm" onClick={() => { toast.success('Şifrə sıfırlama axını üçün baza hazırdır'); }}><KeyRound className="size-4" /> Şifrə sıfırla</Button>
                      <Button variant="ghost" size="sm" onClick={() => toggleUserStatus(user.id)}>{user.isActive ? 'Deaktiv et' : 'Aktiv et'}</Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>{form.id ? 'İstifadəçini redaktə et' : 'Yeni istifadəçi əlavə et'}</DialogTitle><DialogDescription>Ad, e-poçt, rol və aktiv status.</DialogDescription></DialogHeader>
          <div className="grid gap-4">
            <div className="space-y-2"><Label>Ad</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
            <div className="space-y-2"><Label>E-poçt</Label><Input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
            <div className="space-y-2"><Label>Rol</Label>
              <Select value={form.role} onValueChange={(value: User['role']) => setForm({ ...form, role: value })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="super_admin">Super admin</SelectItem>
                  <SelectItem value="manager">Menecer</SelectItem>
                  <SelectItem value="content_editor">Kontent redaktoru</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button onClick={() => { upsertUser({ ...form, id: form.id || createId('user') }); setDialogOpen(false) }}>Yadda saxla</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
