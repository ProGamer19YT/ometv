'use client'

import { useMemo, useState } from 'react'
import { ImagePlus, Search, Trash2 } from 'lucide-react'

import { ConfirmActionDialog } from '@/components/admin/confirm-action-dialog'
import { DragOrderList } from '@/components/admin/drag-order-list'
import { PageHeader } from '@/components/admin/page-header'
import { StatusBadge } from '@/components/admin/status-badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Textarea } from '@/components/ui/textarea'
import { useAdminData } from '@/lib/admin/data-context'
import type { GalleryItem } from '@/lib/admin/types'
import { createId, formatDate } from '@/lib/admin/utils'

export function GalleryManager() {
  const { state, upsertGalleryItem, deleteGalleryItem, reorderGalleryItems } = useAdminData()
  const [search, setSearch] = useState('')
  const [dialogOpen, setDialogOpen] = useState(false)
  const [form, setForm] = useState<GalleryItem>({
    id: '',
    title: '',
    description: '',
    alt: '',
    image: '/placeholder.jpg',
    isCover: false,
    isActive: true,
    order: state.galleryItems.length + 1,
    uploadedAt: new Date().toISOString(),
  })

  const items = useMemo(
    () => state.galleryItems.filter((item) => [item.title, item.description, item.alt].join(' ').toLowerCase().includes(search.toLowerCase())).sort((a, b) => a.order - b.order),
    [search, state.galleryItems],
  )

  const openDialog = (item?: GalleryItem) => {
    setForm(item ?? {
      id: '',
      title: '',
      description: '',
      alt: '',
      image: '/placeholder.jpg',
      isCover: false,
      isActive: true,
      order: state.galleryItems.length + 1,
      uploadedAt: new Date().toISOString(),
    })
    setDialogOpen(true)
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="Qalereya idarəetməsi"
        description="Şəkil yükləmə sahəsi, cover seçimi, alt mətn, grid ön baxış və drag and drop sıralama burada idarə olunur."
        actions={<Button onClick={() => openDialog()}><ImagePlus className="size-4" /> Şəkil yüklə</Button>}
      />

      <Card className="border-border/60 bg-card/70">
        <CardHeader>
          <CardTitle>Filtr və sıralama</CardTitle>
          <CardDescription>Drag and drop sıralamanı dərhal yeniləyir.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="relative">
            <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
            <Input className="pl-9" placeholder="Qalereya daxilində axtarış" value={search} onChange={(e) => setSearch(e.target.value)} />
          </div>
          <DragOrderList items={items} getLabel={(item) => item.title} onChange={reorderGalleryItems} />
        </CardContent>
      </Card>

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {items.map((item) => (
          <Card key={item.id} className="overflow-hidden border-border/60 bg-card/70">
            <img src={item.image} alt={item.alt} className="h-52 w-full object-cover" />
            <CardContent className="space-y-4 px-5 py-5">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="font-medium">{item.title}</p>
                  <p className="text-xs text-muted-foreground">Yüklənmə tarixi: {formatDate(item.uploadedAt)}</p>
                </div>
                {item.isCover ? <StatusBadge label="Əsas şəkil" tone="info" /> : null}
              </div>
              <p className="text-sm text-muted-foreground">{item.description}</p>
              <div className="flex flex-wrap gap-2">
                <StatusBadge label={item.isActive ? 'Aktiv' : 'Passiv'} tone={item.isActive ? 'success' : 'muted'} />
                <Button variant="outline" size="sm" onClick={() => openDialog(item)}>Redaktə et</Button>
                <ConfirmActionDialog
                  trigger={<Button variant="ghost" size="icon-sm"><Trash2 className="size-4" /></Button>}
                  title="Şəkli sil"
                  description="Seçilən qalereya elementini silmək istədiyinizə əminsiniz?"
                  onConfirm={() => deleteGalleryItem(item.id)}
                />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-xl">
          <DialogHeader>
            <DialogTitle>{form.id ? 'Qalereya elementini redaktə et' : 'Yeni şəkil əlavə et'}</DialogTitle>
            <DialogDescription>Real fayl upload servisinə qoşulmağa hazır struktur.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4">
            <div className="space-y-2">
              <Label>Şəkil URL / upload sahəsi</Label>
              <Input value={form.image} onChange={(e) => setForm({ ...form, image: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>Başlıq</Label>
              <Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>Qısa təsvir</Label>
              <Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>Alt mətn</Label>
              <Input value={form.alt} onChange={(e) => setForm({ ...form, alt: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>Sıralama</Label>
              <Input type="number" value={form.order} onChange={(e) => setForm({ ...form, order: Number(e.target.value) })} />
            </div>
            <div className="flex items-center justify-between rounded-2xl border border-border/60 bg-background/40 px-4 py-3">
              <Label>Cover şəkli seç</Label>
              <Switch checked={form.isCover} onCheckedChange={(checked) => setForm({ ...form, isCover: checked })} />
            </div>
            <div className="flex items-center justify-between rounded-2xl border border-border/60 bg-background/40 px-4 py-3">
              <Label>Aktiv / passiv et</Label>
              <Switch checked={form.isActive} onCheckedChange={(checked) => setForm({ ...form, isActive: checked })} />
            </div>
            <Button onClick={() => { upsertGalleryItem({ ...form, id: form.id || createId('gal') }); setDialogOpen(false) }}>Yadda saxla</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
