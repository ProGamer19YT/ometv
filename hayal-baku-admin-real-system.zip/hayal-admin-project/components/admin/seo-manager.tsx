'use client'

import { useState } from 'react'
import { Save, Share2 } from 'lucide-react'

import { PageHeader } from '@/components/admin/page-header'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Textarea } from '@/components/ui/textarea'
import { useAdminData } from '@/lib/admin/data-context'
import type { SEOSettings, SeoEntry } from '@/lib/admin/types'

function SeoFields({ entry, onChange }: { entry: SeoEntry; onChange: (entry: SeoEntry) => void }) {
  return (
    <div className="grid gap-4 md:grid-cols-2">
      <div className="space-y-2 md:col-span-2"><Label>Meta title</Label><Input value={entry.metaTitle} onChange={(e) => onChange({ ...entry, metaTitle: e.target.value })} /></div>
      <div className="space-y-2 md:col-span-2"><Label>Meta description</Label><Textarea value={entry.metaDescription} onChange={(e) => onChange({ ...entry, metaDescription: e.target.value })} /></div>
      <div className="space-y-2 md:col-span-2"><Label>Meta keywords</Label><Input value={entry.metaKeywords} onChange={(e) => onChange({ ...entry, metaKeywords: e.target.value })} /></div>
      <div className="space-y-2"><Label>Open Graph title</Label><Input value={entry.openGraphTitle} onChange={(e) => onChange({ ...entry, openGraphTitle: e.target.value })} /></div>
      <div className="space-y-2"><Label>Open Graph image</Label><Input value={entry.openGraphImage} onChange={(e) => onChange({ ...entry, openGraphImage: e.target.value })} /></div>
      <div className="space-y-2 md:col-span-2"><Label>Open Graph description</Label><Textarea value={entry.openGraphDescription} onChange={(e) => onChange({ ...entry, openGraphDescription: e.target.value })} /></div>
      <div className="space-y-2"><Label>Canonical URL</Label><Input value={entry.canonicalUrl} onChange={(e) => onChange({ ...entry, canonicalUrl: e.target.value })} /></div>
      <div className="space-y-2"><Label>Slug redaktəsi</Label><Input value={entry.slug} onChange={(e) => onChange({ ...entry, slug: e.target.value })} /></div>
      <div className="space-y-2 md:col-span-2"><Label>Schema üçün JSON sahəsi</Label><Textarea className="min-h-40 font-mono text-xs" value={entry.schemaJson} onChange={(e) => onChange({ ...entry, schemaJson: e.target.value })} /></div>
      <div className="flex items-center justify-between rounded-2xl border border-border/60 bg-background/40 px-4 py-3 md:col-span-2"><Label>Robot index ayarı</Label><Switch checked={entry.robotsIndex} onCheckedChange={(checked) => onChange({ ...entry, robotsIndex: checked })} /></div>
    </div>
  )
}

export function SEOManager() {
  const { state, saveSeoSettings } = useAdminData()
  const [form, setForm] = useState<SEOSettings>(state.seoSettings)
  const [isSaving, setIsSaving] = useState(false)

  const save = async () => {
    setIsSaving(true)
    await new Promise((resolve) => setTimeout(resolve, 600))
    saveSeoSettings(form)
    setIsSaving(false)
  }

  return (
    <div className="space-y-6">
      <PageHeader title="SEO ayarları" description="Ümumi sayt və əsas səhifələr üçün meta məlumatlar, Open Graph, canonical, schema və robots parametrlərini idarə edin." actions={<Button onClick={save} disabled={isSaving}><Save className="size-4" /> {isSaving ? 'Saxlanılır...' : 'SEO saxla'}</Button>} />
      <Tabs defaultValue="global" className="space-y-6">
        <TabsList className="grid w-full gap-2 md:grid-cols-5">
          <TabsTrigger value="global">Ümumi SEO</TabsTrigger>
          <TabsTrigger value="home">Ana səhifə SEO</TabsTrigger>
          <TabsTrigger value="menu">Menyu SEO</TabsTrigger>
          <TabsTrigger value="reservation">Rezervasiya SEO</TabsTrigger>
          <TabsTrigger value="contact">Əlaqə SEO</TabsTrigger>
        </TabsList>
        {(['global', 'home', 'menu', 'reservation', 'contact'] as const).map((key) => (
          <TabsContent key={key} value={key}>
            <div className="grid gap-6 xl:grid-cols-[1.05fr_0.95fr]">
              <Card className="border-border/60 bg-card/70">
                <CardHeader><CardTitle>{key === 'global' ? 'Ümumi sayt SEO' : `${key === 'home' ? 'Ana səhifə' : key === 'menu' ? 'Menyu' : key === 'reservation' ? 'Rezervasiya' : 'Əlaqə'} SEO`}</CardTitle></CardHeader>
                <CardContent>
                  <SeoFields entry={form[key]} onChange={(entry) => setForm({ ...form, [key]: entry })} />
                </CardContent>
              </Card>
              <Card className="border-border/60 bg-card/70">
                <CardHeader><CardTitle>Sosial paylaşım preview kartı</CardTitle><CardDescription>Open Graph məlumatlarının ön baxışı.</CardDescription></CardHeader>
                <CardContent>
                  <div className="overflow-hidden rounded-[28px] border border-border/60 bg-background/40">
                    <img src={form[key].openGraphImage} alt="og preview" className="h-52 w-full object-cover" />
                    <div className="space-y-3 p-5">
                      <div className="inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/10 px-3 py-1 text-xs text-primary"><Share2 className="size-4" /> Sosial preview</div>
                      <p className="text-sm text-muted-foreground">{form[key].canonicalUrl}</p>
                      <h3 className="text-lg font-semibold">{form[key].openGraphTitle}</h3>
                      <p className="text-sm text-muted-foreground">{form[key].openGraphDescription}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  )
}
