'use client'

import type { ReactNode } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import {
  BookOpenText,
  ChevronRight,
  ContactRound,
  GalleryHorizontal,
  HelpCircle,
  Home,
  LayoutDashboard,
  LogOut,
  MenuSquare,
  Search,
  Settings,
  ShieldCheck,
  Sparkles,
  Users,
} from 'lucide-react'

import { getRoleLabel } from '@/lib/admin/auth'
import { formatDateTime } from '@/lib/admin/utils'
import { useAdminData } from '@/lib/admin/data-context'
import { LoadingScreen } from '@/components/admin/loading-screen'
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarInset,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarSeparator,
  SidebarTrigger,
} from '@/components/ui/sidebar'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Input } from '@/components/ui/input'

const items = [
  { href: '/admin', label: 'Dashboard', icon: LayoutDashboard },
  { href: '/admin/content', label: 'Sayt məzmunu', icon: Home },
  { href: '/admin/menu', label: 'Menyu idarəetməsi', icon: MenuSquare },
  { href: '/admin/reservations', label: 'Rezervasiyalar', icon: BookOpenText },
  { href: '/admin/group-bookings', label: 'Qrup rezervasiyaları', icon: Sparkles },
  { href: '/admin/gallery', label: 'Qalereya', icon: GalleryHorizontal },
  { href: '/admin/testimonials', label: 'Rəylər', icon: ShieldCheck },
  { href: '/admin/faq', label: 'FAQ', icon: HelpCircle },
  { href: '/admin/contact', label: 'Əlaqə məlumatları', icon: ContactRound },
  { href: '/admin/seo', label: 'SEO ayarları', icon: Search },
  { href: '/admin/users', label: 'İstifadəçilər', icon: Users },
  { href: '/admin/settings', label: 'Ayarlar', icon: Settings },
]

export function AdminShell({ children }: { children: ReactNode }) {
  const pathname = usePathname()
  const { currentUser, signOut, state, isReady } = useAdminData()

  if (!isReady) {
    return <LoadingScreen />
  }

  return (
    <SidebarProvider defaultOpen>
      <Sidebar variant="inset" collapsible="icon">
        <SidebarHeader className="px-3 py-4">
          <div className="flex items-center gap-3 rounded-2xl border border-border/60 bg-card/70 p-3">
            <div className="rounded-2xl bg-primary/10 p-2 text-primary">
              <LayoutDashboard className="size-5" />
            </div>
            <div className="min-w-0 transition group-data-[collapsible=icon]:hidden">
              <p className="truncate text-sm font-semibold">{state.siteSettings.brandName}</p>
              <p className="truncate text-xs text-muted-foreground">Admin idarəetmə paneli</p>
            </div>
          </div>
        </SidebarHeader>
        <SidebarContent>
          <SidebarGroup>
            <SidebarGroupLabel>Naviqasiya</SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {items.map((item) => {
                  const isActive = pathname === item.href
                  return (
                    <SidebarMenuItem key={item.href}>
                      <SidebarMenuButton asChild isActive={isActive} tooltip={item.label}>
                        <Link href={item.href}>
                          <item.icon />
                          <span>{item.label}</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  )
                })}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        </SidebarContent>
        <SidebarSeparator />
        <SidebarFooter className="p-3">
          <Card className="border-border/60 bg-card/60 px-3 py-3 group-data-[collapsible=icon]:hidden">
            <p className="text-sm font-medium">{currentUser?.name}</p>
            <p className="text-xs text-muted-foreground">{getRoleLabel(currentUser?.role ?? 'manager')}</p>
            <p className="mt-1 text-xs text-muted-foreground">
              Son giriş: {currentUser?.lastLogin ? formatDateTime(currentUser.lastLogin) : '—'}
            </p>
          </Card>
          <Button variant="ghost" className="justify-start" onClick={signOut}>
            <LogOut className="size-4" />
            <span className="group-data-[collapsible=icon]:hidden">Çıxış</span>
          </Button>
        </SidebarFooter>
      </Sidebar>

      <SidebarInset className="min-h-screen bg-[radial-gradient(circle_at_top,_rgba(214,165,82,0.08),_transparent_30%),linear-gradient(180deg,rgba(12,10,9,0.98),rgba(18,15,13,1))]">
        <header className="sticky top-0 z-20 border-b border-border/60 bg-background/80 backdrop-blur-xl">
          <div className="flex flex-col gap-4 px-4 py-4 md:flex-row md:items-center md:justify-between md:px-6">
            <div className="flex items-center gap-3">
              <SidebarTrigger />
              <div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <span>İdarəetmə paneli</span>
                  <ChevronRight className="size-4" />
                  <span className="text-foreground">{items.find((item) => item.href === pathname)?.label ?? 'Dashboard'}</span>
                </div>
                <p className="text-xs text-muted-foreground">
                  Son fəaliyyət: {state.auditLogs[0] ? formatDateTime(state.auditLogs[0].timestamp) : 'Məlumat yoxdur'}
                </p>
              </div>
            </div>
            <div className="flex w-full flex-col gap-3 md:w-auto md:flex-row md:items-center">
              <div className="relative min-w-[240px]">
                <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
                <Input className="pl-9" placeholder="Modul daxilində axtarış et" />
              </div>
              <div className="rounded-full border border-primary/20 bg-primary/10 px-3 py-2 text-xs text-primary">
                Aktiv audit qeydi: {state.auditLogs.length}
              </div>
            </div>
          </div>
        </header>
        <div className="p-4 md:p-6">{children}</div>
      </SidebarInset>
    </SidebarProvider>
  )
}
