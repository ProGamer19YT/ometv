'use client'

import { useState } from 'react'
import { Bell, Save } from 'lucide-react'

import { PageHeader } from '@/components/admin/page-header'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { useAdminData } from '@/lib/admin/data-context'

export function SettingsManager() {
  const { state, saveSettings } = useAdminData()
  const [form, setForm] = useState(state.siteSettings)
  const [isSaving, setIsSaving] = useState(false)

  const onSave = async () => {
    setIsSaving(true)
    await new Promise((resolve) => setTimeout(resolve, 600))
    saveSettings(form)
    setIsSaving(false)
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Ayarlar" description="Brend adı, loqo, favicon, tarix və saat formatı, valyuta, bildirişlər və sosial media linkləri üçün ümumi sistem ayarları." actions={<Button onClick={onSave} disabled={isSaving}><Save className="size-4" /> {isSaving ? 'Saxlanılır...' : 'Ayarları yadda saxla'}</Button>} />
      <div className="grid gap-6 xl:grid-cols-[1.05fr_0.95fr]">
        <Card className="border-border/60 bg-card/70">
          <CardHeader><CardTitle>Ümumi ayarlar</CardTitle></CardHeader>
          <CardContent className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2"><Label>Brend adı</Label><Input value={form.brandName} onChange={(e) => setForm({ ...form, brandName: e.target.value })} /></div>
            <div className="space-y-2"><Label>Admin panel dili</Label><Input value={form.panelLanguage} onChange={(e) => setForm({ ...form, panelLanguage: e.target.value })} /></div>
            <div className="space-y-2"><Label>Loqo</Label><Input value={form.logo} onChange={(e) => setForm({ ...form, logo: e.target.value })} /></div>
            <div className="space-y-2"><Label>Favicon</Label><Input value={form.favicon} onChange={(e) => setForm({ ...form, favicon: e.target.value })} /></div>
            <div className="space-y-2"><Label>Tarix formatı</Label><Input value={form.dateFormat} onChange={(e) => setForm({ ...form, dateFormat: e.target.value })} /></div>
            <div className="space-y-2"><Label>Saat formatı</Label><Input value={form.timeFormat} onChange={(e) => setForm({ ...form, timeFormat: e.target.value })} /></div>
            <div className="space-y-2"><Label>Defolt valyuta</Label><Input value={form.defaultCurrency} onChange={(e) => setForm({ ...form, defaultCurrency: e.target.value })} /></div>
            <div className="space-y-2"><Label>WhatsApp link ayarı</Label><Input value={form.whatsappLink} onChange={(e) => setForm({ ...form, whatsappLink: e.target.value })} /></div>
            <div className="space-y-2"><Label>Instagram</Label><Input value={form.socialLinks.instagram} onChange={(e) => setForm({ ...form, socialLinks: { ...form.socialLinks, instagram: e.target.value } })} /></div>
            <div className="space-y-2"><Label>Facebook</Label><Input value={form.socialLinks.facebook} onChange={(e) => setForm({ ...form, socialLinks: { ...form.socialLinks, facebook: e.target.value } })} /></div>
            <div className="space-y-2 md:col-span-2"><Label>TikTok</Label><Input value={form.socialLinks.tiktok} onChange={(e) => setForm({ ...form, socialLinks: { ...form.socialLinks, tiktok: e.target.value } })} /></div>
          </CardContent>
        </Card>
        <Card className="border-border/60 bg-card/70">
          <CardHeader><CardTitle>Bildiriş ayarları</CardTitle><CardDescription>Admin daxilində toast və sistem bildirişləri üçün əsas parametrlər.</CardDescription></CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between rounded-2xl border border-border/60 bg-background/40 px-4 py-3"><div><p className="font-medium">Bildiriş ayarları</p><p className="text-sm text-muted-foreground">Toast və sistem xəbərdarlıqlarını aktiv saxla.</p></div><Switch checked={form.notificationsEnabled} onCheckedChange={(checked) => setForm({ ...form, notificationsEnabled: checked })} /></div>
            <div className="flex items-center justify-between rounded-2xl border border-border/60 bg-background/40 px-4 py-3"><div><p className="font-medium">E-poçt bildirişləri</p><p className="text-sm text-muted-foreground">Rezervasiya və qrup sifarişləri üzrə e-poçt xəbərdarlıqları.</p></div><Switch checked={form.emailNotifications} onCheckedChange={(checked) => setForm({ ...form, emailNotifications: checked })} /></div>
            <div className="rounded-[28px] border border-primary/20 bg-primary/10 p-6 text-primary">
              <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-primary/20 bg-background/20 px-3 py-1 text-xs"><Bell className="size-4" /> Bildiriş nümunəsi</div>
              <p className="font-medium">“Məlumat uğurla yeniləndi”</p>
              <p className="mt-1 text-sm text-primary/80">“Rezervasiya təsdiqləndi”, “Şəkil silindi”, “Xəta baş verdi” kimi toast-lar bu strukturla işləyir.</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
