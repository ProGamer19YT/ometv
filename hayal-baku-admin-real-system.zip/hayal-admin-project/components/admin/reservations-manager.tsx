'use client'

import { useMemo, useState } from 'react'
import { Download, PhoneCall, Search, Trash2 } from 'lucide-react'

import { ConfirmActionDialog } from '@/components/admin/confirm-action-dialog'
import { EmptyState } from '@/components/admin/empty-state'
import { PageHeader } from '@/components/admin/page-header'
import { StatusBadge } from '@/components/admin/status-badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Drawer, DrawerContent, DrawerHeader, DrawerTitle } from '@/components/ui/drawer'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { Textarea } from '@/components/ui/textarea'
import { hasPermission } from '@/lib/admin/auth'
import { useAdminData } from '@/lib/admin/data-context'
import type { Reservation } from '@/lib/admin/types'
import { downloadCsv, formatDateTime, reservationStatusTone } from '@/lib/admin/utils'

const statuses = ['Yeni', 'Gözləyir', 'Təsdiqləndi', 'Ləğv edildi', 'Tamamlandı'] as const

export function ReservationsManager() {
  const { state, currentUser, updateReservationStatus, deleteReservation, addReservationNote } = useAdminData()
  const canManage = hasPermission(currentUser?.role, 'reservations.manage')
  const canDelete = currentUser?.role === 'super_admin' || currentUser?.role === 'manager'

  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState('all')
  const [dateFilter, setDateFilter] = useState('')
  const [selected, setSelected] = useState<Reservation | null>(null)
  const [internalNote, setInternalNote] = useState('')

  const filteredReservations = useMemo(() => {
    return state.reservations.filter((item) => {
      const matchesSearch = [item.name, item.phone, item.note].join(' ').toLowerCase().includes(search.toLowerCase())
      const matchesStatus = statusFilter === 'all' || item.status === statusFilter
      const matchesDate = !dateFilter || item.date === dateFilter
      return matchesSearch && matchesStatus && matchesDate
    })
  }, [dateFilter, search, state.reservations, statusFilter])

  if (!canManage) {
    return <EmptyState icon={Search} title="Bu modul üçün icazəniz yoxdur" description="Rezervasiya idarəetməsi yalnız menecer və super admin üçün aktivdir." />
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="Rezervasiyalar"
        description="Rezervasiya sorğuları, status tarixçəsi, daxili qeyd, detallı drawer və CSV ixrac et üçün hazır struktur."
        actions={
          <Button
            variant="outline"
            onClick={() =>
              downloadCsv(
                'rezervasiyalar.csv',
                filteredReservations.map((item) => ({
                  ad: item.name,
                  telefon: item.phone,
                  qonaq_sayi: item.guestCount,
                  tarix: item.date,
                  saat: item.time,
                  status: item.status,
                  yaradildi: item.createdAt,
                })),
              )
            }
          >
            <Download className="size-4" />
            CSV ixrac et
          </Button>
        }
      />

      <Card className="border-border/60 bg-card/70">
        <CardHeader>
          <CardTitle>Rezervasiya cədvəli</CardTitle>
          <CardDescription>Tarix və status üzrə filtr, axtarış və boş state dizaynı ilə.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-3 md:grid-cols-4">
            <div className="relative md:col-span-2">
              <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
              <Input className="pl-9" placeholder="Ad, telefon və ya qeyd üzrə axtarış" value={search} onChange={(e) => setSearch(e.target.value)} />
            </div>
            <Input type="date" value={dateFilter} onChange={(e) => setDateFilter(e.target.value)} />
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger><SelectValue placeholder="Statusa görə filtr" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Bütün statuslar</SelectItem>
                {statuses.map((status) => <SelectItem key={status} value={status}>{status}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>

          {filteredReservations.length === 0 ? (
            <EmptyState icon={Search} title="Rezervasiya tapılmadı" description="Seçilən filtrə uyğun nəticə yoxdur. Filtrləri təmizləyib yenidən yoxlayın." />
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Ad</TableHead>
                    <TableHead>Telefon nömrəsi</TableHead>
                    <TableHead>Qonaq sayı</TableHead>
                    <TableHead>Tarix</TableHead>
                    <TableHead>Saat</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Yaradılma tarixi</TableHead>
                    <TableHead className="text-right">Əməliyyat</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredReservations.map((item) => (
                    <TableRow key={item.id}>
                      <TableCell className="font-medium">{item.name}</TableCell>
                      <TableCell>{item.phone}</TableCell>
                      <TableCell>{item.guestCount}</TableCell>
                      <TableCell>{item.date}</TableCell>
                      <TableCell>{item.time}</TableCell>
                      <TableCell><StatusBadge label={item.status} tone={reservationStatusTone(item.status)} /></TableCell>
                      <TableCell>{formatDateTime(item.createdAt)}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button variant="ghost" size="sm" onClick={() => setSelected(item)}>Detallara bax</Button>
                          {canDelete ? (
                            <ConfirmActionDialog
                              trigger={<Button variant="ghost" size="icon-sm"><Trash2 className="size-4" /></Button>}
                              title="Rezervasiyanı sil"
                              description="Bu əməliyyat rezervasiyanı siyahıdan siləcək."
                              onConfirm={() => deleteReservation(item.id)}
                            />
                          ) : null}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <Drawer open={Boolean(selected)} onOpenChange={(open) => !open && setSelected(null)}>
        <DrawerContent className="max-h-[90vh]">
          {selected ? (
            <div className="mx-auto w-full max-w-4xl overflow-y-auto px-4 pb-6">
              <DrawerHeader className="px-0">
                <DrawerTitle>Rezervasiya detalları</DrawerTitle>
              </DrawerHeader>
              <div className="grid gap-6 lg:grid-cols-[0.8fr_1.2fr]">
                <Card className="border-border/60 bg-card/70">
                  <CardContent className="space-y-4 px-5 py-5">
                    <div>
                      <p className="text-sm text-muted-foreground">Ad</p>
                      <p className="font-medium">{selected.name}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Telefon</p>
                      <p className="font-medium">{selected.phone}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Qonaq sayı</p>
                      <p className="font-medium">{selected.guestCount}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Tarix / Saat</p>
                      <p className="font-medium">{selected.date} • {selected.time}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Qeyd</p>
                      <p className="text-sm">{selected.note || 'Qeyd yoxdur'}</p>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      <Button asChild variant="outline"><a href={`tel:${selected.phone}`}><PhoneCall className="size-4" /> Müştəri ilə əlaqə</a></Button>
                      <Button variant="outline" onClick={() => updateReservationStatus(selected.id, 'Təsdiqləndi')}>Təsdiqlə</Button>
                      <Button variant="destructive" onClick={() => updateReservationStatus(selected.id, 'Ləğv edildi')}>Ləğv et</Button>
                    </div>
                  </CardContent>
                </Card>

                <div className="space-y-6">
                  <Card className="border-border/60 bg-card/70">
                    <CardHeader>
                      <CardTitle>Status dəyiş</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <Select value={selected.status} onValueChange={(value) => { updateReservationStatus(selected.id, value as Reservation['status']); setSelected({ ...selected, status: value as Reservation['status'] }) }}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {statuses.map((status) => <SelectItem key={status} value={status}>{status}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </CardContent>
                  </Card>

                  <Card className="border-border/60 bg-card/70">
                    <CardHeader>
                      <CardTitle>Daxili qeyd</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <Textarea value={internalNote} onChange={(e) => setInternalNote(e.target.value)} placeholder="Komanda üçün daxili qeyd əlavə edin" />
                      <Button onClick={() => { if (!internalNote.trim()) return; addReservationNote(selected.id, internalNote); setSelected((prev) => prev ? { ...prev, internalNotes: [...prev.internalNotes, internalNote.trim()] } : prev); setInternalNote('') }}>Qeyd əlavə et</Button>
                      <div className="space-y-2">
                        {selected.internalNotes.map((note, index) => (
                          <div key={`${note}-${index}`} className="rounded-2xl border border-border/60 bg-background/40 p-3 text-sm">{note}</div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="border-border/60 bg-card/70">
                    <CardHeader>
                      <CardTitle>Status tarixçəsi</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      {selected.history.map((entry) => (
                        <div key={entry.id} className="flex items-start justify-between gap-3 rounded-2xl border border-border/60 bg-background/40 p-3">
                          <div>
                            <StatusBadge label={entry.status} tone={reservationStatusTone(entry.status)} />
                            <p className="mt-2 text-xs text-muted-foreground">{entry.by}</p>
                          </div>
                          <p className="text-xs text-muted-foreground">{formatDateTime(entry.at)}</p>
                        </div>
                      ))}
                    </CardContent>
                  </Card>
                </div>
              </div>
            </div>
          ) : null}
        </DrawerContent>
      </Drawer>
    </div>
  )
}
