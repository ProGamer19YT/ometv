export type UserRole = 'super_admin' | 'manager' | 'content_editor'

export type ReservationStatus =
  | 'Yeni'
  | 'Gözləyir'
  | 'Təsdiqləndi'
  | 'Ləğv edildi'
  | 'Tamamlandı'

export type GroupBookingStatus =
  | 'Yeni sorğu'
  | 'Baxılır'
  | 'Təklif göndərildi'
  | 'Təsdiqləndi'
  | 'Bağlandı'
  | 'Ləğv edildi'

export interface User {
  id: string
  name: string
  email: string
  role: UserRole
  isActive: boolean
  lastLogin: string
}

export interface ReservationTimelineItem {
  id: string
  status: ReservationStatus
  at: string
  by: string
}

export interface Reservation {
  id: string
  name: string
  phone: string
  guestCount: number
  date: string
  time: string
  note: string
  status: ReservationStatus
  createdAt: string
  internalNotes: string[]
  history: ReservationTimelineItem[]
}

export interface GroupBooking {
  id: string
  personOrCompany: string
  phone: string
  email: string
  eventType: string
  guestCount: number
  date: string
  time: string
  budget: string
  proposalAmount?: string
  note: string
  adminNote: string
  status: GroupBookingStatus
  createdAt: string
}

export interface MenuCategory {
  id: string
  name: string
  isActive: boolean
  order: number
}

export interface MenuItem {
  id: string
  name: string
  description: string
  price: number
  image: string
  categoryId: string
  isSignature: boolean
  availability: 'Mövcuddur' | 'Mövcud deyil'
  order: number
  isActive: boolean
}

export interface GalleryItem {
  id: string
  title: string
  description: string
  alt: string
  image: string
  isCover: boolean
  isActive: boolean
  order: number
  uploadedAt: string
}

export interface Testimonial {
  id: string
  customerName: string
  text: string
  rating: number
  image?: string
  isVisible: boolean
  order: number
}

export interface FAQItem {
  id: string
  question: string
  answer: string
  order: number
  isActive: boolean
}

export interface ContactInfo {
  address: string
  phone: string
  alternatePhone: string
  email: string
  workingHours: string
  instagram: string
  mapsEmbedUrl: string
  parkingInfo: string
  shortDescription: string
}

export interface SeoEntry {
  metaTitle: string
  metaDescription: string
  metaKeywords: string
  openGraphTitle: string
  openGraphDescription: string
  openGraphImage: string
  canonicalUrl: string
  slug: string
  schemaJson: string
  robotsIndex: boolean
}

export interface SEOSettings {
  global: SeoEntry
  home: SeoEntry
  menu: SeoEntry
  reservation: SeoEntry
  contact: SeoEntry
}

export interface SiteContent {
  hero: {
    title: string
    subtitle: string
    primaryCta: string
    secondaryCta: string
    tags: string[]
    visual: string
    isActive: boolean
  }
  about: {
    title: string
    text: string
    cards: Array<{ id: string; title: string; text: string }>
  }
  signatureExperience: {
    title: string
    subtitle: string
    cards: Array<{ id: string; title: string; description: string; order: number }>
  }
  finalCta: {
    title: string
    description: string
    primaryButton: string
    secondaryButton: string
  }
  footer: {
    description: string
    links: Array<{ id: string; label: string; href: string }>
    copyright: string
  }
}

export interface SiteSettings {
  brandName: string
  logo: string
  favicon: string
  panelLanguage: string
  dateFormat: string
  timeFormat: string
  defaultCurrency: string
  notificationsEnabled: boolean
  emailNotifications: boolean
  whatsappLink: string
  socialLinks: {
    instagram: string
    facebook: string
    tiktok: string
  }
}

export interface AuditLog {
  id: string
  action: string
  module: string
  user: string
  timestamp: string
  detail: string
}

export interface AdminDataState {
  users: User[]
  reservations: Reservation[]
  groupBookings: GroupBooking[]
  menuCategories: MenuCategory[]
  menuItems: MenuItem[]
  galleryItems: GalleryItem[]
  testimonials: Testimonial[]
  faqItems: FAQItem[]
  contactInfo: ContactInfo
  seoSettings: SEOSettings
  siteContent: SiteContent
  siteSettings: SiteSettings
  auditLogs: AuditLog[]
}
