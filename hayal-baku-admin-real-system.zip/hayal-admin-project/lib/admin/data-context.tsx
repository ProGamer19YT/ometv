'use client'

import * as React from 'react'
import type { ReactNode } from 'react'
import { toast } from 'sonner'

import type {
  AdminDataState,
  AuditLog,
  ContactInfo,
  FAQItem,
  GalleryItem,
  GroupBooking,
  GroupBookingStatus,
  MenuCategory,
  MenuItem,
  ReservationStatus,
  SEOSettings,
  SiteContent,
  SiteSettings,
  Testimonial,
  User,
} from '@/lib/admin/types'
import { demoAdminState } from '@/lib/admin/demo-data'
import { loadAdminState, saveAdminState } from '@/lib/admin/storage'
import { createId, pushAuditLog } from '@/lib/admin/utils'
import { ADMIN_CURRENT_USER_KEY, ADMIN_SESSION_COOKIE } from '@/lib/admin/constants'

interface AdminDataContextValue {
  state: AdminDataState
  isReady: boolean
  currentUser: User | null
  setCurrentUser: (user: User | null) => void
  signOut: () => void
  saveSiteContent: (payload: SiteContent) => void
  upsertMenuCategory: (payload: MenuCategory) => void
  deleteMenuCategory: (id: string) => void
  upsertMenuItem: (payload: MenuItem) => void
  deleteMenuItem: (id: string) => void
  bulkSetMenuItemsActive: (ids: string[], isActive: boolean) => void
  bulkDeleteMenuItems: (ids: string[]) => void
  updateReservationStatus: (id: string, status: ReservationStatus) => void
  addReservationNote: (id: string, note: string) => void
  deleteReservation: (id: string) => void
  upsertGroupBooking: (payload: GroupBooking) => void
  updateGroupBookingStatus: (id: string, status: GroupBookingStatus) => void
  deleteGroupBooking: (id: string) => void
  upsertGalleryItem: (payload: GalleryItem) => void
  deleteGalleryItem: (id: string) => void
  reorderGalleryItems: (items: GalleryItem[]) => void
  upsertTestimonial: (payload: Testimonial) => void
  deleteTestimonial: (id: string) => void
  upsertFaqItem: (payload: FAQItem) => void
  deleteFaqItem: (id: string) => void
  reorderFaqItems: (items: FAQItem[]) => void
  saveContactInfo: (payload: ContactInfo) => void
  saveSeoSettings: (payload: SEOSettings) => void
  upsertUser: (payload: User) => void
  toggleUserStatus: (id: string) => void
  saveSettings: (payload: SiteSettings) => void
  addAuditLog: (log: Omit<AuditLog, 'id' | 'timestamp' | 'user'>) => void
}

const AdminDataContext = React.createContext<AdminDataContextValue | null>(null)

function usePersistedState() {
  const [state, setState] = React.useState<AdminDataState>(demoAdminState)
  const [isReady, setIsReady] = React.useState(false)
  const [currentUser, setCurrentUserState] = React.useState<User | null>(null)

  React.useEffect(() => {
    const initialState = loadAdminState()
    setState(initialState)
    const rawCurrentUser = window.localStorage.getItem(ADMIN_CURRENT_USER_KEY)
    if (rawCurrentUser) {
      try {
        setCurrentUserState(JSON.parse(rawCurrentUser) as User)
      } catch {
        setCurrentUserState(null)
      }
    }
    setIsReady(true)
  }, [])

  const persist = React.useCallback((updater: AdminDataState | ((prev: AdminDataState) => AdminDataState)) => {
    setState((prev) => {
      const next = typeof updater === 'function' ? updater(prev) : updater
      saveAdminState(next)
      return next
    })
  }, [])

  const setCurrentUser = React.useCallback((user: User | null) => {
    setCurrentUserState(user)
    if (user) {
      window.localStorage.setItem(ADMIN_CURRENT_USER_KEY, JSON.stringify(user))
    } else {
      window.localStorage.removeItem(ADMIN_CURRENT_USER_KEY)
    }
  }, [])

  return { state, persist, isReady, currentUser, setCurrentUser }
}

export function AdminDataProvider({ children }: { children: ReactNode }) {
  const { state, persist, isReady, currentUser, setCurrentUser } = usePersistedState()

  const addAuditLog = React.useCallback(
    (log: Omit<AuditLog, 'id' | 'timestamp' | 'user'>) => {
      persist((prev) => ({
        ...prev,
        auditLogs: pushAuditLog(prev.auditLogs, {
          id: createId('log'),
          timestamp: new Date().toISOString(),
          user: currentUser?.name ?? 'Sistem admin',
          ...log,
        }),
      }))
    },
    [currentUser?.name, persist],
  )

  const signOut = React.useCallback(() => {
    setCurrentUser(null)
    document.cookie = `${ADMIN_SESSION_COOKIE}=; path=/; max-age=0`
    toast.success('Sessiya bağlandı')
    window.location.href = '/admin/login'
  }, [setCurrentUser])

  const saveSiteContent = React.useCallback(
    (payload: SiteContent) => {
      persist((prev) => ({ ...prev, siteContent: payload }))
      addAuditLog({ action: 'Məzmun yeniləndi', module: 'Sayt məzmunu', detail: 'Sayt məzmun modulu saxlanıldı.' })
      toast.success('Məlumat uğurla yeniləndi')
    },
    [addAuditLog, persist],
  )

  const upsertMenuCategory = React.useCallback(
    (payload: MenuCategory) => {
      persist((prev) => ({
        ...prev,
        menuCategories: prev.menuCategories.some((item) => item.id === payload.id)
          ? prev.menuCategories.map((item) => (item.id === payload.id ? payload : item))
          : [...prev.menuCategories, payload],
      }))
      addAuditLog({ action: 'Kateqoriya saxlanıldı', module: 'Menyu', detail: `${payload.name} kateqoriyası yadda saxlanıldı.` })
      toast.success('Kateqoriya yadda saxlanıldı')
    },
    [addAuditLog, persist],
  )

  const deleteMenuCategory = React.useCallback(
    (id: string) => {
      const category = state.menuCategories.find((item) => item.id === id)
      persist((prev) => ({
        ...prev,
        menuCategories: prev.menuCategories.filter((item) => item.id !== id),
        menuItems: prev.menuItems.filter((item) => item.categoryId !== id),
      }))
      addAuditLog({ action: 'Kateqoriya silindi', module: 'Menyu', detail: `${category?.name ?? 'Kateqoriya'} silindi.` })
      toast.success('Kateqoriya silindi')
    },
    [addAuditLog, persist, state.menuCategories],
  )

  const upsertMenuItem = React.useCallback(
    (payload: MenuItem) => {
      persist((prev) => ({
        ...prev,
        menuItems: prev.menuItems.some((item) => item.id === payload.id)
          ? prev.menuItems.map((item) => (item.id === payload.id ? payload : item))
          : [...prev.menuItems, payload],
      }))
      addAuditLog({ action: 'Məhsul saxlanıldı', module: 'Menyu', detail: `${payload.name} məhsulu saxlanıldı.` })
      toast.success('Məhsul yadda saxlanıldı')
    },
    [addAuditLog, persist],
  )

  const deleteMenuItem = React.useCallback(
    (id: string) => {
      const item = state.menuItems.find((entry) => entry.id === id)
      persist((prev) => ({ ...prev, menuItems: prev.menuItems.filter((entry) => entry.id !== id) }))
      addAuditLog({ action: 'Məhsul silindi', module: 'Menyu', detail: `${item?.name ?? 'Məhsul'} silindi.` })
      toast.success('Məhsul silindi')
    },
    [addAuditLog, persist, state.menuItems],
  )

  const bulkSetMenuItemsActive = React.useCallback(
    (ids: string[], isActive: boolean) => {
      persist((prev) => ({
        ...prev,
        menuItems: prev.menuItems.map((item) => (ids.includes(item.id) ? { ...item, isActive } : item)),
      }))
      addAuditLog({
        action: isActive ? 'Məhsullar aktiv edildi' : 'Məhsullar deaktiv edildi',
        module: 'Menyu',
        detail: `${ids.length} məhsul üçün toplu status dəyişildi.`,
      })
      toast.success(isActive ? 'Seçilən məhsullar aktiv edildi' : 'Seçilən məhsullar deaktiv edildi')
    },
    [addAuditLog, persist],
  )

  const bulkDeleteMenuItems = React.useCallback(
    (ids: string[]) => {
      persist((prev) => ({ ...prev, menuItems: prev.menuItems.filter((item) => !ids.includes(item.id)) }))
      addAuditLog({ action: 'Toplu silmə', module: 'Menyu', detail: `${ids.length} məhsul silindi.` })
      toast.success('Seçilən məhsullar silindi')
    },
    [addAuditLog, persist],
  )

  const updateReservationStatus = React.useCallback(
    (id: string, status: ReservationStatus) => {
      const reservation = state.reservations.find((item) => item.id === id)
      persist((prev) => ({
        ...prev,
        reservations: prev.reservations.map((item) =>
          item.id === id
            ? {
                ...item,
                status,
                history: [
                  ...item.history,
                  {
                    id: createId('res_hist'),
                    status,
                    at: new Date().toISOString(),
                    by: currentUser?.name ?? 'Sistem admin',
                  },
                ],
              }
            : item,
        ),
      }))
      addAuditLog({ action: 'Rezervasiya statusu dəyişdi', module: 'Rezervasiyalar', detail: `${reservation?.name ?? 'Rezervasiya'} -> ${status}` })
      toast.success(status === 'Təsdiqləndi' ? 'Rezervasiya təsdiqləndi' : 'Rezervasiya yeniləndi')
    },
    [addAuditLog, currentUser?.name, persist, state.reservations],
  )

  const addReservationNote = React.useCallback(
    (id: string, note: string) => {
      if (!note.trim()) {
        toast.error('Məcburi sahələri doldurun')
        return
      }
      persist((prev) => ({
        ...prev,
        reservations: prev.reservations.map((item) =>
          item.id === id ? { ...item, internalNotes: [...item.internalNotes, note.trim()] } : item,
        ),
      }))
      addAuditLog({ action: 'Daxili qeyd əlavə olundu', module: 'Rezervasiyalar', detail: 'Rezervasiya üçün daxili qeyd əlavə edildi.' })
      toast.success('Daxili qeyd əlavə olundu')
    },
    [addAuditLog, persist],
  )

  const deleteReservation = React.useCallback(
    (id: string) => {
      const reservation = state.reservations.find((item) => item.id === id)
      persist((prev) => ({ ...prev, reservations: prev.reservations.filter((item) => item.id !== id) }))
      addAuditLog({ action: 'Rezervasiya silindi', module: 'Rezervasiyalar', detail: `${reservation?.name ?? 'Rezervasiya'} silindi.` })
      toast.success('Rezervasiya silindi')
    },
    [addAuditLog, persist, state.reservations],
  )

  const upsertGroupBooking = React.useCallback(
    (payload: GroupBooking) => {
      persist((prev) => ({
        ...prev,
        groupBookings: prev.groupBookings.some((item) => item.id === payload.id)
          ? prev.groupBookings.map((item) => (item.id === payload.id ? payload : item))
          : [...prev.groupBookings, payload],
      }))
      addAuditLog({ action: 'Qrup sorğusu saxlanıldı', module: 'Qrup rezervasiyaları', detail: `${payload.personOrCompany} sorğusu saxlanıldı.` })
      toast.success('Sorğu yadda saxlanıldı')
    },
    [addAuditLog, persist],
  )

  const updateGroupBookingStatus = React.useCallback(
    (id: string, status: GroupBookingStatus) => {
      const booking = state.groupBookings.find((item) => item.id === id)
      persist((prev) => ({
        ...prev,
        groupBookings: prev.groupBookings.map((item) => (item.id === id ? { ...item, status } : item)),
      }))
      addAuditLog({ action: 'Qrup sorğusu yeniləndi', module: 'Qrup rezervasiyaları', detail: `${booking?.personOrCompany ?? 'Sorğu'} -> ${status}` })
      toast.success('Qrup rezervasiyası yeniləndi')
    },
    [addAuditLog, persist, state.groupBookings],
  )

  const deleteGroupBooking = React.useCallback(
    (id: string) => {
      const booking = state.groupBookings.find((item) => item.id === id)
      persist((prev) => ({ ...prev, groupBookings: prev.groupBookings.filter((item) => item.id !== id) }))
      addAuditLog({ action: 'Qrup sorğusu silindi', module: 'Qrup rezervasiyaları', detail: `${booking?.personOrCompany ?? 'Sorğu'} silindi.` })
      toast.success('Sorğu silindi')
    },
    [addAuditLog, persist, state.groupBookings],
  )

  const upsertGalleryItem = React.useCallback(
    (payload: GalleryItem) => {
      persist((prev) => ({
        ...prev,
        galleryItems: prev.galleryItems.some((item) => item.id === payload.id)
          ? prev.galleryItems.map((item) =>
              item.id === payload.id ? payload : payload.isCover ? { ...item, isCover: false } : item,
            )
          : [...prev.galleryItems.map((item) => (payload.isCover ? { ...item, isCover: false } : item)), payload],
      }))
      addAuditLog({ action: 'Qalereya elementi saxlanıldı', module: 'Qalereya', detail: `${payload.title} saxlanıldı.` })
      toast.success('Şəkil yadda saxlanıldı')
    },
    [addAuditLog, persist],
  )

  const deleteGalleryItem = React.useCallback(
    (id: string) => {
      const item = state.galleryItems.find((entry) => entry.id === id)
      persist((prev) => ({ ...prev, galleryItems: prev.galleryItems.filter((entry) => entry.id !== id) }))
      addAuditLog({ action: 'Qalereya elementi silindi', module: 'Qalereya', detail: `${item?.title ?? 'Şəkil'} silindi.` })
      toast.success('Şəkil silindi')
    },
    [addAuditLog, persist, state.galleryItems],
  )

  const reorderGalleryItems = React.useCallback(
    (items: GalleryItem[]) => {
      persist((prev) => ({ ...prev, galleryItems: items.map((item, index) => ({ ...item, order: index + 1 })) }))
      addAuditLog({ action: 'Qalereya sıralandı', module: 'Qalereya', detail: 'Drag and drop ilə sıralama yeniləndi.' })
      toast.success('Qalereya sıralaması yeniləndi')
    },
    [addAuditLog, persist],
  )

  const upsertTestimonial = React.useCallback(
    (payload: Testimonial) => {
      persist((prev) => ({
        ...prev,
        testimonials: prev.testimonials.some((item) => item.id === payload.id)
          ? prev.testimonials.map((item) => (item.id === payload.id ? payload : item))
          : [...prev.testimonials, payload],
      }))
      addAuditLog({ action: 'Rəy saxlanıldı', module: 'Rəylər', detail: `${payload.customerName} üçün rəy yadda saxlanıldı.` })
      toast.success('Rəy yadda saxlanıldı')
    },
    [addAuditLog, persist],
  )

  const deleteTestimonial = React.useCallback(
    (id: string) => {
      const item = state.testimonials.find((entry) => entry.id === id)
      persist((prev) => ({ ...prev, testimonials: prev.testimonials.filter((entry) => entry.id !== id) }))
      addAuditLog({ action: 'Rəy silindi', module: 'Rəylər', detail: `${item?.customerName ?? 'Rəy'} silindi.` })
      toast.success('Rəy silindi')
    },
    [addAuditLog, persist, state.testimonials],
  )

  const upsertFaqItem = React.useCallback(
    (payload: FAQItem) => {
      persist((prev) => ({
        ...prev,
        faqItems: prev.faqItems.some((item) => item.id === payload.id)
          ? prev.faqItems.map((item) => (item.id === payload.id ? payload : item))
          : [...prev.faqItems, payload],
      }))
      addAuditLog({ action: 'FAQ saxlanıldı', module: 'FAQ', detail: `${payload.question} sualı saxlanıldı.` })
      toast.success('FAQ yadda saxlanıldı')
    },
    [addAuditLog, persist],
  )

  const deleteFaqItem = React.useCallback(
    (id: string) => {
      const item = state.faqItems.find((entry) => entry.id === id)
      persist((prev) => ({ ...prev, faqItems: prev.faqItems.filter((entry) => entry.id !== id) }))
      addAuditLog({ action: 'FAQ silindi', module: 'FAQ', detail: `${item?.question ?? 'FAQ'} silindi.` })
      toast.success('FAQ silindi')
    },
    [addAuditLog, persist, state.faqItems],
  )

  const reorderFaqItems = React.useCallback(
    (items: FAQItem[]) => {
      persist((prev) => ({ ...prev, faqItems: items.map((item, index) => ({ ...item, order: index + 1 })) }))
      addAuditLog({ action: 'FAQ sıralandı', module: 'FAQ', detail: 'FAQ sıralaması yeniləndi.' })
      toast.success('FAQ sıralaması yeniləndi')
    },
    [addAuditLog, persist],
  )

  const saveContactInfo = React.useCallback(
    (payload: ContactInfo) => {
      persist((prev) => ({ ...prev, contactInfo: payload }))
      addAuditLog({ action: 'Əlaqə məlumatları yeniləndi', module: 'Əlaqə', detail: 'Əlaqə məlumatları saxlanıldı.' })
      toast.success('Əlaqə məlumatları yeniləndi')
    },
    [addAuditLog, persist],
  )

  const saveSeoSettings = React.useCallback(
    (payload: SEOSettings) => {
      persist((prev) => ({ ...prev, seoSettings: payload }))
      addAuditLog({ action: 'SEO ayarları yeniləndi', module: 'SEO', detail: 'SEO parametrləri saxlanıldı.' })
      toast.success('SEO ayarları yeniləndi')
    },
    [addAuditLog, persist],
  )

  const upsertUser = React.useCallback(
    (payload: User) => {
      persist((prev) => ({
        ...prev,
        users: prev.users.some((item) => item.id === payload.id)
          ? prev.users.map((item) => (item.id === payload.id ? payload : item))
          : [...prev.users, payload],
      }))
      addAuditLog({ action: 'İstifadəçi saxlanıldı', module: 'İstifadəçilər', detail: `${payload.name} istifadəçisi saxlanıldı.` })
      toast.success('İstifadəçi yadda saxlanıldı')
    },
    [addAuditLog, persist],
  )

  const toggleUserStatus = React.useCallback(
    (id: string) => {
      const target = state.users.find((item) => item.id === id)
      persist((prev) => ({
        ...prev,
        users: prev.users.map((item) => (item.id === id ? { ...item, isActive: !item.isActive } : item)),
      }))
      addAuditLog({ action: 'İstifadəçi statusu dəyişdi', module: 'İstifadəçilər', detail: `${target?.name ?? 'İstifadəçi'} statusu dəyişdirildi.` })
      toast.success('İstifadəçi statusu yeniləndi')
    },
    [addAuditLog, persist, state.users],
  )

  const saveSettings = React.useCallback(
    (payload: SiteSettings) => {
      persist((prev) => ({ ...prev, siteSettings: payload }))
      addAuditLog({ action: 'Ayarlar yeniləndi', module: 'Ayarlar', detail: 'Ümumi sistem ayarları saxlanıldı.' })
      toast.success('Ayarlar saxlanıldı')
    },
    [addAuditLog, persist],
  )

  const value = React.useMemo<AdminDataContextValue>(
    () => ({
      state,
      isReady,
      currentUser,
      setCurrentUser,
      signOut,
      saveSiteContent,
      upsertMenuCategory,
      deleteMenuCategory,
      upsertMenuItem,
      deleteMenuItem,
      bulkSetMenuItemsActive,
      bulkDeleteMenuItems,
      updateReservationStatus,
      addReservationNote,
      deleteReservation,
      upsertGroupBooking,
      updateGroupBookingStatus,
      deleteGroupBooking,
      upsertGalleryItem,
      deleteGalleryItem,
      reorderGalleryItems,
      upsertTestimonial,
      deleteTestimonial,
      upsertFaqItem,
      deleteFaqItem,
      reorderFaqItems,
      saveContactInfo,
      saveSeoSettings,
      upsertUser,
      toggleUserStatus,
      saveSettings,
      addAuditLog,
    }),
    [
      state,
      isReady,
      currentUser,
      setCurrentUser,
      signOut,
      saveSiteContent,
      upsertMenuCategory,
      deleteMenuCategory,
      upsertMenuItem,
      deleteMenuItem,
      bulkSetMenuItemsActive,
      bulkDeleteMenuItems,
      updateReservationStatus,
      addReservationNote,
      deleteReservation,
      upsertGroupBooking,
      updateGroupBookingStatus,
      deleteGroupBooking,
      upsertGalleryItem,
      deleteGalleryItem,
      reorderGalleryItems,
      upsertTestimonial,
      deleteTestimonial,
      upsertFaqItem,
      deleteFaqItem,
      reorderFaqItems,
      saveContactInfo,
      saveSeoSettings,
      upsertUser,
      toggleUserStatus,
      saveSettings,
      addAuditLog,
    ],
  )

  return <AdminDataContext.Provider value={value}>{children}</AdminDataContext.Provider>
}

export function useAdminData() {
  const context = React.useContext(AdminDataContext)
  if (!context) {
    throw new Error('useAdminData must be used within AdminDataProvider')
  }
  return context
}
