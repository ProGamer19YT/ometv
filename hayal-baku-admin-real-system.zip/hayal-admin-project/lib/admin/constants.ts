export const ADMIN_SESSION_COOKIE = 'hayal_baku_admin_session'
export const ADMIN_STORAGE_KEY = 'hayal-baku-admin-state-v2'
export const ADMIN_CURRENT_USER_KEY = 'hayal-baku-admin-current-user-v2'

export const roleLabels = {
  super_admin: 'Super admin',
  manager: 'Menecer',
  content_editor: 'Kontent redaktoru',
} as const

export const permissions = {
  super_admin: ['*'],
  manager: [
    'dashboard.view',
    'content.manage',
    'menu.manage',
    'reservations.manage',
    'group.manage',
    'gallery.manage',
    'testimonials.manage',
    'faq.manage',
    'contact.manage',
    'seo.manage',
    'settings.manage',
  ],
  content_editor: [
    'dashboard.view',
    'content.manage',
    'menu.manage',
    'gallery.manage',
    'testimonials.manage',
    'faq.manage',
    'contact.manage',
    'seo.manage',
  ],
} as const
