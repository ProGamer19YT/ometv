import { ADMIN_STORAGE_KEY } from '@/lib/admin/constants'
import type { AdminDataState } from '@/lib/admin/types'
import { demoAdminState } from '@/lib/admin/demo-data'

export function loadAdminState(): AdminDataState {
  if (typeof window === 'undefined') return demoAdminState

  const raw = window.localStorage.getItem(ADMIN_STORAGE_KEY)
  if (!raw) return demoAdminState

  try {
    return JSON.parse(raw) as AdminDataState
  } catch {
    return demoAdminState
  }
}

export function saveAdminState(state: AdminDataState) {
  if (typeof window === 'undefined') return
  window.localStorage.setItem(ADMIN_STORAGE_KEY, JSON.stringify(state))
}
