import { ADMIN_CURRENT_USER_KEY, permissions, roleLabels } from '@/lib/admin/constants'
import type { User, UserRole } from '@/lib/admin/types'

export function getRoleLabel(role: UserRole) {
  return roleLabels[role]
}

export function hasPermission(role: UserRole | undefined, permission: string) {
  if (!role) return false
  const allowed = permissions[role] as readonly string[]
  return allowed.includes('*') || allowed.includes(permission)
}

export function getAuthUserFromStorage(): User | null {
  if (typeof window === 'undefined') return null

  const raw = window.localStorage.getItem(ADMIN_CURRENT_USER_KEY)
  if (!raw) return null

  try {
    return JSON.parse(raw) as User
  } catch {
    return null
  }
}
