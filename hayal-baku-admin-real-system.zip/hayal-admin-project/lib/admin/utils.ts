import type { AuditLog, GroupBookingStatus, ReservationStatus } from '@/lib/admin/types'

export function createId(prefix: string) {
  return `${prefix}_${Math.random().toString(36).slice(2, 9)}`
}

export function formatDate(date: string) {
  return new Intl.DateTimeFormat('az-AZ', {
    year: 'numeric',
    month: 'short',
    day: '2-digit',
  }).format(new Date(date))
}

export function formatDateTime(date: string) {
  return new Intl.DateTimeFormat('az-AZ', {
    year: 'numeric',
    month: 'short',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  }).format(new Date(date))
}

export function reservationStatusTone(status: ReservationStatus) {
  switch (status) {
    case 'Təsdiqləndi':
    case 'Tamamlandı':
      return 'success'
    case 'Yeni':
      return 'info'
    case 'Gözləyir':
      return 'warning'
    case 'Ləğv edildi':
      return 'danger'
    default:
      return 'muted'
  }
}

export function groupBookingStatusTone(status: GroupBookingStatus) {
  switch (status) {
    case 'Təsdiqləndi':
    case 'Bağlandı':
      return 'success'
    case 'Yeni sorğu':
      return 'info'
    case 'Baxılır':
    case 'Təklif göndərildi':
      return 'warning'
    case 'Ləğv edildi':
      return 'danger'
    default:
      return 'muted'
  }
}

export function downloadCsv(filename: string, rows: Record<string, string | number>[]) {
  const headers = Object.keys(rows[0] ?? {})
  const content = [
    headers.join(','),
    ...rows.map((row) => headers.map((key) => JSON.stringify(row[key] ?? '')).join(',')),
  ].join('\n')
  const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' })
  const link = document.createElement('a')
  link.href = URL.createObjectURL(blob)
  link.download = filename
  link.click()
  URL.revokeObjectURL(link.href)
}

export function pushAuditLog(logs: AuditLog[], item: AuditLog) {
  return [item, ...logs].slice(0, 50)
}
